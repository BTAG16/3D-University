// landing-sections.jsx — Premium landing page sections v2
// Depends on: landing-components.jsx (Icon, Button, Container, Reveal, Mockups, etc.)

const { useState, useEffect } = React;

// ——— Hero Section — centered big-screenshot style ———
const HeroSection = () => {
  const isMobile = useIsMobile();
  const [entered, setEntered] = useState(false);
  useEffect(() => { const t = setTimeout(() => setEntered(true), 60); return () => clearTimeout(t); }, []);

  const fade = (delay) => ({
    opacity: entered ? 1 : 0,
    transform: entered ? 'translateY(0)' : 'translateY(22px)',
    transition: `opacity 0.85s cubic-bezier(0.16,1,0.3,1) ${delay}ms, transform 0.85s cubic-bezier(0.16,1,0.3,1) ${delay}ms`,
  });

  return (
    <section style={{
      paddingTop: isMobile ? 'calc(var(--nav-height) + 48px)' : 'calc(var(--nav-height) + 80px)',
      paddingBottom: isMobile ? 40 : 20, background: 'var(--bg)',
      overflow: 'hidden', position: 'relative',
    }}>
      {/* Premium gradient background */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(14,165,233,0.06) 0%, transparent 60%)',
      }}/>
      <div style={{
        position: 'absolute', top: '30%', right: '-10%', width: 500, height: 500,
        background: 'radial-gradient(circle, rgba(14,165,233,0.04) 0%, transparent 60%)',
        pointerEvents: 'none',
      }}/>
      {/* Dot grid */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.15, pointerEvents: 'none' }}>
        <pattern id="heroDots" width="28" height="28" patternUnits="userSpaceOnUse">
          <circle cx="1" cy="1" r="0.8" fill="currentColor" opacity="0.4"/>
        </pattern>
        <rect width="100%" height="100%" fill="url(#heroDots)" style={{ color: 'var(--text-tertiary)' }}/>
      </svg>

      {/* Text — centered */}
      <Container style={{ textAlign: 'center', position: 'relative', zIndex: 1 }}>
        {/* Badge */}
        <div style={{ ...fade(60), display: 'flex', justifyContent: 'center', marginBottom: 24 }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 7,
            background: 'var(--accent-subtle)', color: 'var(--accent)',
            border: '1px solid var(--accent-muted)',
            fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-display)',
            padding: '5px 16px 5px 10px', borderRadius: 9999, letterSpacing: '0.03em',
          }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--accent)', display: 'inline-block' }}></span>
            Built for Universities
          </span>
        </div>

        {/* H1 */}
        <h1 style={{
          ...fade(160),
          fontFamily: 'var(--font-display)', fontWeight: 800,
          fontSize: isMobile ? 46 : 84,
          lineHeight: 1.0, letterSpacing: '-0.04em',
          color: 'var(--text-primary)',
          margin: '0 auto 24px',
          maxWidth: isMobile ? '100%' : 820,
        }}>
          Your campus,<br/>
          <span style={{ color: 'var(--accent)' }}>mapped beautifully.</span>
        </h1>

        {/* Subtitle */}
        <p style={{
          ...fade(280),
          fontSize: isMobile ? 17 : 20, color: 'var(--text-secondary)',
          lineHeight: 1.65, maxWidth: 560,
          margin: '0 auto 40px',
        }}>
          Give students an interactive 3D map of your campus — buildings, rooms, timetables, and walking directions, all in one shareable link.
        </p>

        {/* CTAs */}
        <div style={{
          ...fade(380),
          display: 'flex', alignItems: 'center', gap: 16, justifyContent: 'center',
          flexDirection: isMobile ? 'column' : 'row', marginBottom: 28,
        }}>
          <Button variant="pill" size="lg" icon="arrowRight" href="Admin Login.html">Get started free</Button>
          <Button variant="link" size="lg" icon="arrowRight" href="Demo Map.html" style={{ color: 'var(--accent)' }}>
            See live demo
          </Button>
        </div>

        {/* Trust line */}
        <div style={{
          ...fade(480),
          display: 'flex', gap: isMobile ? 20 : 36,
          fontSize: 13, color: 'var(--text-tertiary)',
          justifyContent: 'center', flexWrap: 'wrap', marginBottom: 72,
        }}>
          {['No credit card', '5 minute setup', 'Free for your first campus'].map(t => (
            <span key={t} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ color: 'var(--success)' }}><Icon name="check" size={13} /></span> {t}
            </span>
          ))}
        </div>
      </Container>

      {/* Big 3D perspective screenshot */}
      <div style={{
        ...fade(260),
        position: 'relative', zIndex: 1,
        maxWidth: 1100, margin: '0 auto',
        padding: isMobile ? '0 16px' : '0 40px',
        marginTop: isMobile ? 32 : 8,
      }}>
        {/* Ambient glow behind screenshot */}
        <div style={{
          position: 'absolute', top: '5%', left: '10%',
          width: '80%', height: '90%',
          background: 'radial-gradient(ellipse, rgba(14,165,233,0.1) 0%, transparent 60%)',
          filter: 'blur(60px)', pointerEvents: 'none', zIndex: 0,
        }}/>

        {/* Screenshot — 3D tilt: viewed from above-right, left recedes */}
        <div style={{
          position: 'relative', zIndex: 1,
          width: '100%',
          height: isMobile ? 220 : 520,
          transform: isMobile ? 'none' : 'perspective(2000px) rotateX(8deg) rotateY(-10deg)',
          transformOrigin: '50% 50%',
          borderRadius: 14,
          overflow: 'hidden',
          boxShadow: '0 40px 100px -20px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.06), 0 0 60px -10px rgba(14,165,233,0.08)',
        }}>
          <CampusMapScreenshot />
        </div>

        {/* Bottom-edge fade */}
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0,
          height: isMobile ? 50 : 100,
          background: 'linear-gradient(to bottom, transparent, var(--bg))',
          pointerEvents: 'none', zIndex: 2, borderRadius: '0 0 14px 14px',
        }}/>
      </div>
    </section>
  );
};

// ——— Social Proof ———
const SocialProofBar = () => {
  const isMobile = useIsMobile();
  return (
    <section style={{ padding: '52px 0', background: 'var(--surface)', borderTop: '1px solid var(--border-light)' }}>
      <Reveal>
        <Container>
          <p style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-tertiary)', textAlign: 'center', marginBottom: 28, letterSpacing: '0.02em' }}>
            Trusted by universities in 3 countries
          </p>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: isMobile ? 24 : 56, flexWrap: 'wrap' }}>
            {['Budapest Tech', 'Ankara Uni', 'Sofia State', 'Debrecen Uni'].map(u => <UniLogo key={u} name={u} />)}
          </div>
        </Container>
      </Reveal>
    </section>
  );
};

// ——— Features Overview Grid ———
const FeaturesOverview = () => {
  const isMobile = useIsMobile();
  const features = [
    { icon: 'globe', title: '3D Interactive Map' },
    { icon: 'search', title: 'Smart Search' },
    { icon: 'compass', title: 'Walking Directions' },
    { icon: 'layers', title: 'Indoor Navigation' },
    { icon: 'calendar', title: 'Room Timetables' },
    { icon: 'link', title: 'One Link, Shareable' },
  ];
  return (
    <section id="features" style={{ padding: isMobile ? '64px 0' : '100px 0', background: 'var(--bg)' }}>
      <Container>
        <Reveal>
          <div style={{ textAlign: 'center', marginBottom: isMobile ? 40 : 56 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: isMobile ? 30 : 44, letterSpacing: '-0.025em', color: 'var(--text-primary)', lineHeight: 1.12 }}>
              The complete campus platform
            </h2>
            <p style={{ fontSize: 18, color: 'var(--text-secondary)', marginTop: 14, maxWidth: 480, margin: '14px auto 0', lineHeight: 1.6 }}>
              Everything students need to navigate campus, built into one link.
            </p>
          </div>
        </Reveal>
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? 'repeat(2, 1fr)' : 'repeat(6, 1fr)', gap: isMobile ? 12 : 16 }}>
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 80}>
              <div style={{
                textAlign: 'center', padding: isMobile ? '20px 12px' : '28px 16px',
                borderRadius: 12, background: 'var(--surface)', border: '1px solid var(--border-light)',
                transition: 'all 250ms ease',
              }}>
                <div style={{
                  width: 44, height: 44, borderRadius: 12, margin: '0 auto 12px',
                  background: 'var(--accent-subtle)', color: 'var(--accent)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Icon name={f.icon} size={20} />
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}>{f.title}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
};

// ——— Feature Showcase (reusable alternating section) ———
const FeatureShowcase = ({ id, eyebrow, title, description, bullets, mockup, reversed, bgColor = 'var(--surface)' }) => {
  const isMobile = useIsMobile();
  return (
    <section id={id} style={{ padding: isMobile ? '64px 0' : '100px 0', background: bgColor }}>
      <Container style={{
        display: 'flex', alignItems: 'center',
        flexDirection: isMobile ? 'column' : (reversed ? 'row-reverse' : 'row'),
        gap: isMobile ? 40 : 80,
      }}>
        {/* Text */}
        <Reveal direction={reversed ? 'right' : 'left'} style={{ flex: '0 1 48%' }}>
          <div style={{
            fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-display)',
            color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.1em',
            marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <span style={{ width: 20, height: 1, background: 'var(--accent)' }}></span>
            {eyebrow}
          </div>
          <h3 style={{
            fontFamily: 'var(--font-display)', fontWeight: 700,
            fontSize: isMobile ? 26 : 34, letterSpacing: '-0.025em',
            color: 'var(--text-primary)', lineHeight: 1.15, marginBottom: 16,
          }}>{title}</h3>
          <p style={{ fontSize: 16, color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 24 }}>{description}</p>
          {bullets && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {bullets.map((b, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                  <div style={{ width: 22, height: 22, borderRadius: 6, background: 'var(--accent-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
                    <Icon name="check" size={12} />
                  </div>
                  <span style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{b}</span>
                </div>
              ))}
            </div>
          )}
        </Reveal>
        {/* Mockup */}
        <Reveal delay={200} direction={reversed ? 'left' : 'right'} style={{ flex: '0 1 52%', display: 'flex', justifyContent: 'center' }}>
          {mockup}
        </Reveal>
      </Container>
    </section>
  );
};

// ——— Feature Deep Dives ———
const FeatureDeepDives = () => (
  <>
    <FeatureShowcase
      id="feature-map"
      eyebrow="Core Experience"
      title="A 3D interactive campus map students actually use"
      description="Powered by Mapbox, your campus comes alive with 3D building extrusions, smooth fly-to animations, and real-time location. Students search, explore, and get directions — no app download required."
      bullets={[
        'Mapbox GL 3D rendering with building height data',
        'Custom markers with category icons and clustering',
        'Works on any device — desktop, tablet, or phone',
        'Dark mode toggle for the map view',
      ]}
      mockup={<BrowserMockup />}
    />
    <FeatureShowcase
      id="feature-dashboard"
      eyebrow="Admin Experience"
      title="A dashboard that makes campus data management effortless"
      description="Add buildings, rooms, timetables, and facilities from a clean admin interface. No technical skills needed — if you can fill a form, you can run your campus map."
      bullets={[
        'Add buildings with coordinates, categories, and operating hours',
        'Manage rooms with office hours, capacity, and weekly timetables',
        'Copy your public link or embed code in one click',
        'Track visitor analytics and map engagement',
      ]}
      mockup={<DashboardMockup />}
      reversed
      bgColor="var(--bg)"
    />
    <FeatureShowcase
      id="feature-search"
      eyebrow="Student Experience"
      title="Find anything on campus in seconds"
      description="Smart search covers buildings, rooms, departments, and facilities. Filter by category, sort by distance, and get walking directions or hand off to Google Maps."
      bullets={[
        'Instant search across all campus data',
        'Filter by Academic, Library, Sports, Dining, and more',
        'Walking time estimates with location services',
        'Indoor navigation via Mappedin integration',
      ]}
      mockup={<PhoneMockup />}
    />
  </>
);

// ——— How It Works ———
const HowItWorksSection = () => {
  const isMobile = useIsMobile();
  const steps = [
    { num: '01', icon: 'userPlus', title: 'Sign up your university', desc: 'Create an admin account in 60 seconds. No credit card, no commitment.' },
    { num: '02', icon: 'building', title: 'Add buildings & rooms', desc: 'Use the visual dashboard to enter details, coordinates, and schedules.' },
    { num: '03', icon: 'share', title: 'Share the link', desc: 'Students open it instantly — zero login, zero download, zero friction.' },
  ];
  return (
    <section id="how-it-works" style={{ padding: isMobile ? '64px 0' : '100px 0', background: 'var(--bg)' }}>
      <Container>
        <Reveal>
          <div style={{ textAlign: 'center', marginBottom: isMobile ? 48 : 72 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: isMobile ? 30 : 44, letterSpacing: '-0.025em', color: 'var(--text-primary)', lineHeight: 1.12 }}>
              Live in three steps
            </h2>
            <p style={{ fontSize: 18, color: 'var(--text-secondary)', marginTop: 14 }}>From sign-up to live campus map in under five minutes.</p>
          </div>
        </Reveal>
        <div style={{ display: 'flex', flexDirection: isMobile ? 'column' : 'row', gap: isMobile ? 36 : 0, position: 'relative' }}>
          {/* Connecting line (desktop) */}
          {!isMobile && (
            <div style={{ position: 'absolute', top: 48, left: '20%', right: '20%', height: 2, background: 'var(--border)', zIndex: 0 }}></div>
          )}
          {steps.map((s, i) => (
            <Reveal key={s.num} delay={i * 150} style={{ flex: 1, textAlign: 'center', position: 'relative', zIndex: 1 }}>
              <div style={{
                width: 72, height: 72, borderRadius: '50%', margin: '0 auto 20px',
                background: 'var(--surface)', border: '2px solid var(--accent)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 4px 16px rgba(14,165,233,0.12)',
              }}>
                <span style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-display)', color: 'var(--accent)' }}>{s.num}</span>
              </div>
              <div style={{ width: 48, height: 48, borderRadius: 12, margin: '0 auto 14px', background: 'var(--accent-subtle)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={s.icon} size={22} />
              </div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 18, color: 'var(--text-primary)', marginBottom: 8 }}>{s.title}</h3>
              <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, maxWidth: 260, margin: '0 auto' }}>{s.desc}</p>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
};

// ——— Demo Section (Dark) ———
const DemoSection = () => {
  const isMobile = useIsMobile();
  return (
    <section id="demo" style={{ padding: isMobile ? '72px 0' : '112px 0', background: 'var(--navy)', position: 'relative', overflow: 'hidden' }}>
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.05 }}>
        <pattern id="topo" width="200" height="200" patternUnits="userSpaceOnUse">
          <circle cx="100" cy="100" r="80" fill="none" stroke="#fff" strokeWidth="0.5"/>
          <circle cx="100" cy="100" r="50" fill="none" stroke="#fff" strokeWidth="0.5"/>
          <circle cx="100" cy="100" r="20" fill="none" stroke="#fff" strokeWidth="0.5"/>
        </pattern>
        <rect width="100%" height="100%" fill="url(#topo)"/>
      </svg>
      <Reveal>
        <Container style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <div style={{ fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>Live Demo</div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: isMobile ? 30 : 48, letterSpacing: '-0.025em', color: '#fff', lineHeight: 1.1, marginBottom: 16 }}>
            See it before you build it
          </h2>
          <p style={{ fontSize: 18, color: '#8899ac', marginBottom: 40, maxWidth: 420, margin: '0 auto 40px', lineHeight: 1.6 }}>
            Explore a demo campus with real buildings, rooms, and timetables already loaded.
          </p>
          <Button variant="pill-white" size="lg" icon="arrowRight" href="Demo Map.html">Try the Demo</Button>
        </Container>
      </Reveal>
    </section>
  );
};

// ——— FAQ Section (replaces pricing) ———
const FAQSection = () => {
  const isMobile = useIsMobile();
  const faqs = [
    { q: 'Is Kampus 3D really free?', a: 'Yes. We offer the full platform free for your first campus. We believe in letting you experience the value before any conversation about pricing for multi-campus deployments.' },
    { q: 'How long does it take to set up?', a: 'Most universities are live within a day. Create an admin account (60 seconds), add your buildings and rooms via our dashboard (a few hours depending on campus size), and share the link. No technical integration required.' },
    { q: 'Do students need to download an app?', a: 'No. Your campus map is a web link — students open it in any browser on any device. No app store, no login, no friction. You can also embed it directly on your university website.' },
    { q: 'Where does the map data come from?', a: 'You add your own building data through the admin dashboard — names, categories, coordinates, operating hours, facilities, and room schedules. The base map (streets, terrain) comes from Mapbox.' },
    { q: 'Can I add indoor navigation?', a: 'Yes. If your buildings are mapped on Mappedin, you can link each building to its indoor map. Students tap "Indoor Navigation" and get floor-by-floor wayfinding inside the building.' },
    { q: 'What about data privacy?', a: 'Student location data stays in the browser — we never transmit or store individual positions. Admin data is encrypted. You can read our full privacy policy for details.' },
    { q: 'Can I embed the map on our university website?', a: 'Absolutely. We provide a ready-to-use iframe embed code in your admin dashboard. Just copy and paste it into your site.' },
    { q: 'What if I need help setting up?', a: 'We offer hands-on onboarding support. Reach out to our team and we will help you add your campus data and get live quickly.' },
  ];
  return (
    <section id="faq" style={{ padding: isMobile ? '64px 0' : '100px 0', background: 'var(--surface)' }}>
      <Container narrow>
        <Reveal>
          <div style={{ textAlign: 'center', marginBottom: isMobile ? 40 : 56 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: isMobile ? 30 : 44, letterSpacing: '-0.025em', color: 'var(--text-primary)', lineHeight: 1.12 }}>
              Frequently asked questions
            </h2>
            <p style={{ fontSize: 18, color: 'var(--text-secondary)', marginTop: 14 }}>Everything you need to know.</p>
          </div>
        </Reveal>
        <div style={{ maxWidth: 680, margin: '0 auto' }}>
          {faqs.map((f, i) => (
            <Reveal key={i} delay={i * 60}>
              <FAQItem question={f.q} answer={f.a} />
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
};

const FAQItem = ({ question, answer }) => {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ borderBottom: '1px solid var(--border-light)' }}>
      <button onClick={() => setOpen(!open)} style={{
        width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 0', background: 'none', border: 'none', cursor: 'pointer',
        textAlign: 'left', gap: 16,
      }}>
        <span style={{ fontSize: 16, fontWeight: 600, fontFamily: 'var(--font-display)', color: 'var(--text-primary)', lineHeight: 1.4 }}>{question}</span>
        <span style={{
          width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
          background: open ? 'var(--accent)' : 'var(--accent-subtle)',
          color: open ? '#fff' : 'var(--accent)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 200ms ease', transform: open ? 'rotate(45deg)' : 'none',
          fontSize: 18, fontWeight: 300, lineHeight: 1,
        }}>+</span>
      </button>
      <div style={{
        overflow: 'hidden', maxHeight: open ? 300 : 0,
        transition: 'max-height 0.35s cubic-bezier(0.16,1,0.3,1)',
      }}>
        <p style={{ fontSize: 15, color: 'var(--text-secondary)', lineHeight: 1.7, paddingBottom: 20, textWrap: 'pretty' }}>
          {answer}
        </p>
      </div>
    </div>
  );
};

// ——— Testimonials ———
const TestimonialsSection = () => {
  const isMobile = useIsMobile();
  const testimonials = [
    { name: 'Dr. Anna Varga', title: 'Head of Student Affairs', university: 'Budapest Tech', quote: 'We deployed Kampus in a week. Students actually use it now instead of calling our office for directions.' },
    { name: 'Mehmet Yılmaz', title: 'IT Director', university: 'Ankara University', quote: 'The admin dashboard is incredibly intuitive. We added 40 buildings in one afternoon.' },
    { name: 'Elena Petrova', title: 'Campus Operations', university: 'Sofia State University', quote: 'The indoor navigation feature has been a game-changer for our new students during orientation week.' },
  ];
  return (
    <section style={{ padding: isMobile ? '64px 0' : '88px 0', background: 'var(--bg)' }}>
      <Container>
        <Reveal>
          <div style={{ textAlign: 'center', marginBottom: isMobile ? 32 : 48 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: isMobile ? 28 : 36, letterSpacing: '-0.02em', color: 'var(--text-primary)', lineHeight: 1.15 }}>
              Loved by campus teams
            </h2>
          </div>
        </Reveal>
        <div style={{ display: 'flex', gap: 20, flexDirection: isMobile ? 'column' : 'row' }}>
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 120} style={{ flex: 1 }}>
              <TestimonialCard {...t} />
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
};

// ——— Final CTA ———
const CTABanner = () => {
  const isMobile = useIsMobile();
  return (
    <section style={{ padding: isMobile ? '72px 0' : '96px 0', background: 'var(--accent)', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
      {/* Radial glow */}
      <div style={{ position: 'absolute', top: '-50%', left: '50%', transform: 'translateX(-50%)', width: '120%', height: '200%', background: 'radial-gradient(ellipse at center, rgba(255,255,255,0.08) 0%, transparent 60%)', pointerEvents: 'none' }}></div>
      <Reveal>
        <Container style={{ position: 'relative', zIndex: 1 }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: isMobile ? 30 : 44, letterSpacing: '-0.025em', color: '#fff', lineHeight: 1.12, marginBottom: 16 }}>
            Ready to put your campus on the map?
          </h2>
          <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.7)', marginBottom: 32, maxWidth: 440, margin: '0 auto 32px' }}>
            Free setup, free hosting, free support. Your students deserve a better map.
          </p>
          <Button variant="pill-white" size="lg" icon="arrowRight" href="Admin Login.html">Get started free</Button>
        </Container>
      </Reveal>
    </section>
  );
};

// ——— Footer ———
const FooterSection = () => {
  const isMobile = useIsMobile();
  const cols = [
    { title: 'Product', links: [
      { label: 'Features', href: '#features' },
      { label: 'Demo', href: 'Demo Map.html' },
      { label: 'FAQ', href: '#faq' },
    ]},
    { title: 'Company', links: [
      { label: 'About', href: '#' },
      { label: 'Blog', href: '#' },
      { label: 'Contact', href: '#' },
    ]},
    { title: 'Legal', links: [
      { label: 'Privacy Policy', href: 'Privacy Policy.html' },
      { label: 'Terms of Service', href: 'Terms of Service.html' },
    ]},
  ];
  return (
    <footer style={{ padding: isMobile ? '48px 0 24px' : '64px 0 24px', background: 'var(--surface)', borderTop: '1px solid var(--border-light)' }}>
      <Container>
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '2fr 1fr 1fr 1fr', gap: isMobile ? 32 : 48, marginBottom: 48 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ color: 'var(--accent)' }}><Icon name="mapPin" size={20} /></div>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--text-primary)' }}>Kampus</span>
            </div>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, maxWidth: 260 }}>
              Interactive 3D campus maps for universities. Built with care in Budapest.
            </p>
          </div>
          {cols.map(c => (
            <div key={c.title}>
              <div style={{ fontSize: 13, fontWeight: 600, fontFamily: 'var(--font-display)', color: 'var(--text-primary)', marginBottom: 16, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{c.title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {c.links.map(l => <a key={l.label} href={l.href} className="footer-link" style={{ fontSize: 14, color: 'var(--text-secondary)', textDecoration: 'none' }}>{l.label}</a>)}
              </div>
            </div>
          ))}
        </div>
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexDirection: isMobile ? 'column' : 'row', gap: 12 }}>
          <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>© 2025 Kampus 3D. All rights reserved.</span>
          <div style={{ display: 'flex', gap: 20 }}>
            <a href="Privacy Policy.html" style={{ fontSize: 13, color: 'var(--text-tertiary)', textDecoration: 'none' }}>Privacy</a>
            <a href="Terms of Service.html" style={{ fontSize: 13, color: 'var(--text-tertiary)', textDecoration: 'none' }}>Terms</a>
          </div>
        </div>
      </Container>
    </footer>
  );
};

// ——— Cookie Banner ———
const CookieBanner = () => {
  const [visible, setVisible] = useState(true);
  const isMobile = useIsMobile();
  if (!visible) return null;
  return (
    <div style={{
      position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 90,
      background: 'var(--surface)', borderTop: '1px solid var(--border)', padding: '14px 24px',
      display: 'flex', alignItems: isMobile ? 'flex-start' : 'center',
      justifyContent: 'space-between', gap: 16, flexDirection: isMobile ? 'column' : 'row',
    }}>
      <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: 0 }}>
        We use cookies to improve your experience.{' '}
        <a href="Privacy Policy.html" style={{ color: 'var(--accent)', textDecoration: 'underline' }}>Read our Privacy Policy</a>.
      </p>
      <div style={{ display: 'flex', gap: 12, flexShrink: 0 }}>
        <Button variant="pill" size="sm" onClick={() => setVisible(false)}>Accept all</Button>
        <button onClick={() => setVisible(false)} style={{ fontSize: 13, color: 'var(--text-secondary)', background: 'none', border: 'none', cursor: 'pointer' }}>Reject non-essential</button>
      </div>
    </div>
  );
};

// Keep PricingSection export for backward compatibility (unused now)
const PricingSection = () => null;

Object.assign(window, {
  HeroSection, SocialProofBar, FeaturesOverview, FeatureShowcase, FeatureDeepDives,
  FeaturesSection: FeaturesOverview, HowItWorksSection, DemoSection,
  FAQSection, PricingSection, TestimonialsSection, CTABanner,
  FooterSection, CookieBanner,
});
