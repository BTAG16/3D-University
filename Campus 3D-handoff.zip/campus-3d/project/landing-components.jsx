// landing-components.jsx — Shared UI components for Kampus 3D Landing Page
const { useState, useEffect, useRef, useCallback } = React;

// ——— Hooks ———
const useIsMobile = () => {
  const [m, setM] = useState(window.innerWidth < 768);
  useEffect(() => {
    const h = () => setM(window.innerWidth < 768);
    window.addEventListener('resize', h);
    return () => window.removeEventListener('resize', h);
  }, []);
  return m;
};

// ——— Scroll Reveal ———
const useScrollReveal = (opts = {}) => {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setVisible(true); obs.unobserve(el); }
    }, { threshold: 0.08, ...opts });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return [ref, visible];
};

const Reveal = ({ children, delay = 0, direction = 'up', style = {}, className = '' }) => {
  const [ref, visible] = useScrollReveal();
  const offsets = { up: 'translateY(32px)', down: 'translateY(-32px)', left: 'translateX(32px)', right: 'translateX(-32px)', none: 'none' };
  return (
    <div ref={ref} className={className} style={{
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0) translateX(0)' : offsets[direction],
      transition: `opacity 0.7s cubic-bezier(0.16,1,0.3,1) ${delay}ms, transform 0.7s cubic-bezier(0.16,1,0.3,1) ${delay}ms`,
      willChange: 'opacity, transform', ...style,
    }}>
      {children}
    </div>
  );
};

// ——— Icon Component ———
const Svg = ({ children, size = 20, style = {}, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"
    strokeLinejoin="round" style={{ flexShrink: 0, ...style }} className={className}>
    {children}
  </svg>
);

const ICONS = {
  mapPin: (s) => <Svg size={s}><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></Svg>,
  menu: (s) => <Svg size={s}><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></Svg>,
  x: (s) => <Svg size={s}><path d="M18 6 6 18M6 6l12 12"/></Svg>,
  arrowRight: (s) => <Svg size={s}><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></Svg>,
  check: (s) => <Svg size={s}><path d="M20 6 9 17l-5-5"/></Svg>,
  search: (s) => <Svg size={s}><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></Svg>,
  globe: (s) => <Svg size={s}><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></Svg>,
  compass: (s) => <Svg size={s}><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88"/></Svg>,
  layers: (s) => <Svg size={s}><path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.5-8.97 4.08a2 2 0 0 1-1.66 0L2 17.5"/><path d="m22 12.5-8.97 4.08a2 2 0 0 1-1.66 0L2 12.5"/></Svg>,
  calendar: (s) => <Svg size={s}><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></Svg>,
  link: (s) => <Svg size={s}><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></Svg>,
  building: (s) => <Svg size={s}><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M12 6h.01M12 10h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01M12 14h.01"/></Svg>,
  userPlus: (s) => <Svg size={s}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></Svg>,
  share: (s) => <Svg size={s}><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></Svg>,
  zap: (s) => <Svg size={s}><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></Svg>,
  chevronRight: (s) => <Svg size={s}><path d="m9 18 6-6-6-6"/></Svg>,
  door: (s) => <Svg size={s}><path d="M18 20V6a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v14"/><path d="M2 20h20"/><path d="M14 12v.01"/></Svg>,
  navigation: (s) => <Svg size={s}><polygon points="3 11 22 2 13 21 11 13 3 11"/></Svg>,
  shield: (s) => <Svg size={s}><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></Svg>,
  sun: (s) => <Svg size={s}><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></Svg>,
  moon: (s) => <Svg size={s}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></Svg>,
  externalLink: (s) => <Svg size={s}><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></Svg>,
};

const Icon = ({ name, size = 20 }) => (ICONS[name] ? ICONS[name](size) : null);

// ——— Button ———
const Button = ({ variant = 'primary', size = 'md', children, icon, href, style: extraStyle = {}, ...props }) => {
  const [hovered, setHovered] = useState(false);
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14,
    borderRadius: 8, cursor: 'pointer', border: 'none',
    transition: 'all var(--duration) var(--ease)',
    textDecoration: 'none', whiteSpace: 'nowrap', lineHeight: 1,
  };
  const sizes = {
    sm: { padding: '8px 16px', height: 36, fontSize: 13 },
    md: { padding: '10px 20px', height: 40 },
    lg: { padding: '14px 28px', height: 48, fontSize: 16 },
  };
  const variants = {
    primary: { background: hovered ? 'var(--accent-hover)' : 'var(--accent)', color: '#fff' },
    outline: { background: hovered ? 'var(--accent-subtle)' : '#fff', color: 'var(--accent)', border: '1px solid var(--accent)' },
    ghost: { background: hovered ? '#f3f4f6' : 'transparent', color: 'var(--text-secondary)' },
    pill: { background: hovered ? 'var(--accent-hover)' : 'var(--accent)', color: '#fff', borderRadius: 9999 },
    'pill-outline': { background: hovered ? 'var(--accent-subtle)' : '#fff', color: 'var(--accent)', border: '1px solid var(--border)', borderRadius: 9999 },
    'pill-white': { background: hovered ? '#f3f4f6' : '#fff', color: 'var(--text-primary)', borderRadius: 9999 },
    danger: { background: hovered ? '#dc2626' : 'var(--error)', color: '#fff' },
    link: { background: 'none', color: hovered ? 'var(--accent-hover)' : 'var(--accent)', padding: 0, height: 'auto' },
  };
  const s = { ...base, ...sizes[size], ...variants[variant], ...extraStyle };
  const Tag = href ? 'a' : 'button';
  return (
    <Tag style={s} href={href} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)} {...props}>
      {children}
      {icon && <Icon name={icon} size={size === 'lg' ? 18 : 16} />}
    </Tag>
  );
};

// ——— Container ———
const Container = ({ children, style = {}, narrow, ...props }) => (
  <div style={{ maxWidth: narrow ? 800 : 'var(--container)', margin: '0 auto', padding: '0 24px', width: '100%', ...style }} {...props}>
    {children}
  </div>
);

// ——— Feature Icon Circle ———
const FeatureIcon = ({ name, color = 'var(--accent)', bgColor = 'var(--accent-subtle)', size = 48 }) => (
  <div style={{
    width: size, height: size, borderRadius: 12, display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: bgColor, color: color, flexShrink: 0,
  }}>
    <Icon name={name} size={size * 0.46} />
  </div>
);

// ——— Dark Mode Toggle ———
const DarkToggle = ({ dark, onToggle }) => {
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={onToggle}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      title={dark ? 'Switch to light mode' : 'Switch to dark mode'}
      style={{
        width: 36, height: 36, borderRadius: 8, border: '1px solid var(--border)',
        background: hov ? 'var(--accent-subtle)' : 'var(--surface)',
        color: dark ? '#f0c040' : 'var(--text-secondary)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', transition: 'all 200ms ease', flexShrink: 0,
      }}>
      <Icon name={dark ? 'sun' : 'moon'} size={16} />
    </button>
  );
};

// ——— Nav ———
const Nav = ({ accent, darkMode, onToggleDark }) => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const isMobile = useIsMobile();

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  const links = [
    { label: 'Features', href: '#features' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Demo', href: 'Demo Map.html' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <>
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, height: 64,
        background: darkMode
          ? (scrolled ? 'rgba(11,17,32,0.92)' : 'rgba(11,17,32,0.85)')
          : (scrolled ? 'rgba(255,255,255,0.92)' : 'rgba(255,255,255,0.98)'),
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderBottom: `1px solid ${scrolled ? 'var(--border)' : 'transparent'}`,
        display: 'flex', alignItems: 'center', padding: '0 24px',
        transition: 'all var(--duration-md) var(--ease)',
      }}>
        <Container style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 0 }}>
          {/* Logo */}
          <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 8, textDecoration: 'none' }}>
            <div style={{ color: 'var(--accent)', display: 'flex' }}>{ICONS.mapPin(22)}</div>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
              Kampus
            </span>
          </a>

          {/* Desktop links */}
          {!isMobile && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
              {links.map(l => (
                <a key={l.label} href={l.href}
                  className="nav-link"
                  style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-secondary)', textDecoration: 'none', transition: 'color var(--duration) var(--ease)' }}>
                  {l.label}
                </a>
              ))}
            </div>
          )}

          {/* Desktop CTA */}
          {!isMobile && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <DarkToggle dark={darkMode} onToggle={onToggleDark} />
              <a href="Admin Login.html" className="nav-link" style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-secondary)', textDecoration: 'none' }}>Log in</a>
              <Button variant="pill" size="sm" href="Admin Login.html">Get Started Free</Button>
            </div>
          )}

          {/* Mobile right: dark toggle + hamburger */}
          {isMobile && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <DarkToggle dark={darkMode} onToggle={onToggleDark} />
              <button onClick={() => setOpen(!open)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-primary)', padding: 4 }}>
                {open ? <Icon name="x" size={24} /> : <Icon name="menu" size={24} />}
              </button>
            </div>
          )}
        </Container>
      </nav>

      {/* Mobile drawer */}
      {isMobile && (
        <div style={{
          position: 'fixed', top: 64, left: 0, right: 0, bottom: 0, zIndex: 99,
          background: 'var(--surface)', padding: '24px',
          transform: open ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform var(--duration-md) var(--ease)',
          display: 'flex', flexDirection: 'column', gap: 8,
        }}>
          {links.map(l => (
            <a key={l.label} href={l.href}
              onClick={() => setOpen(false)}
              style={{ fontSize: 18, fontWeight: 600, fontFamily: 'var(--font-display)', color: 'var(--text-primary)', textDecoration: 'none', padding: '12px 0', borderBottom: '1px solid var(--border-light)' }}>
              {l.label}
            </a>
          ))}
          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <a href="Admin Login.html" style={{ fontSize: 16, fontWeight: 500, color: 'var(--text-secondary)', textDecoration: 'none', padding: '8px 0' }}>Log in</a>
            <Button variant="pill" size="lg" style={{ width: '100%' }} href="Admin Login.html">Get Started Free</Button>
          </div>
        </div>
      )}
    </>
  );
};

// ——— Detailed Campus Map Product Screenshot ———
const CampusMapScreenshot = () => {
  const BLDGS = [
    { id:1, name:'Main Library', cat:'Library',      dist:'2 min', color:'#7C3AED', x:148, y:118, w:72, h:52 },
    { id:2, name:'Engineering Building', cat:'Academic',    dist:'4 min', color:'#0EA5E9', x:344, y:92,  w:88, h:58, sel:true },
    { id:3, name:'Student Center', cat:'Student Life', dist:'1 min', color:'#F59E0B', x:258, y:248, w:74, h:48 },
    { id:4, name:'Science Complex', cat:'Academic',    dist:'6 min', color:'#10B981', x:100, y:260, w:80, h:54 },
    { id:5, name:'Admin Building', cat:'Administration', dist:'5 min', color:'#EF4444', x:458, y:272, w:64, h:52 },
    { id:6, name:'Sports Center', cat:'Sports',       dist:'8 min', color:'#EC4899', x:506, y:168, w:58, h:68 },
  ];

  return (
    <div style={{
      width: '100%', height: '100%',
      borderRadius: 12, overflow: 'hidden',
      boxShadow: '0 40px 100px -20px rgba(0,0,0,0.22), 0 0 0 1px rgba(0,0,0,0.06)',
      background: '#fff', fontFamily: 'var(--font-body)',
    }}>
      {/* Browser chrome */}
      <div style={{ height: 36, background: '#F5F5F5', borderBottom: '1px solid #E5E7EB', display: 'flex', alignItems: 'center', padding: '0 14px', gap: 8 }}>
        <div style={{ display: 'flex', gap: 5 }}>
          {['#FF5F57','#FEBC2E','#28C840'].map(c => <span key={c} style={{ width: 10, height: 10, borderRadius: '50%', background: c, display: 'block' }}></span>)}
        </div>
        <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
          <div style={{ background: '#EBEBEB', borderRadius: 6, height: 22, width: 220, display: 'flex', alignItems: 'center', padding: '0 10px', gap: 5 }}>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#999" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a14.5 14.5 0 0 0 0 20"/></svg>
            <span style={{ fontSize: 11, color: '#6B7280' }}>campus.youruni.edu/map</span>
          </div>
        </div>
      </div>

      {/* App shell */}
      <div style={{ display: 'flex', height: 'calc(100% - 36px)' }}>
        {/* Sidebar */}
        <div style={{ width: 252, borderRight: '1px solid #E9ECF0', display: 'flex', flexDirection: 'column', background: '#fff', flexShrink: 0 }}>
          {/* Top */}
          <div style={{ padding: '12px 14px 10px', borderBottom: '1px solid #F3F4F6' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 9 }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              <span style={{ fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)', color: '#101828', letterSpacing: '-0.01em' }}>Budapest Tech University</span>
            </div>
            <div style={{ background: '#F9FAFB', borderRadius: 7, height: 30, display: 'flex', alignItems: 'center', padding: '0 9px', gap: 6, border: '1px solid #E9ECF0' }}>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
              <span style={{ fontSize: 10.5, color: '#9CA3AF' }}>Search buildings, rooms…</span>
            </div>
            <div style={{ display: 'flex', gap: 4, marginTop: 7 }}>
              {['All','Academic','Library','Sports'].map((c,i) => (
                <span key={c} style={{ fontSize: 9.5, padding: '2.5px 8px', borderRadius: 9999, background: i===0 ? 'var(--accent)' : '#F3F4F6', color: i===0 ? '#fff' : '#6B7280', fontWeight: 500 }}>{c}</span>
              ))}
            </div>
          </div>
          {/* List */}
          <div style={{ flex: 1, overflowY: 'hidden', padding: '6px 6px' }}>
            {BLDGS.map(b => (
              <div key={b.id} style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '7px 8px', borderRadius: 7, marginBottom: 1,
                background: b.sel ? 'var(--accent-subtle)' : 'transparent',
                borderLeft: `3px solid ${b.sel ? 'var(--accent)' : 'transparent'}`,
              }}>
                <div style={{ width: 30, height: 30, borderRadius: 7, background: `${b.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={b.color} strokeWidth="1.5"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M12 10h.01"/></svg>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 11, fontWeight: b.sel ? 700 : 600, color: b.sel ? 'var(--accent)' : '#101828', lineHeight: 1.3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.name}</div>
                  <div style={{ fontSize: 9.5, color: '#9CA3AF', display: 'flex', gap: 5 }}>
                    <span>{b.cat}</span>
                    <span style={{ color: b.sel ? 'var(--accent)' : '#BFC5CF' }}>~{b.dist}</span>
                  </div>
                </div>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke={b.sel ? 'var(--accent)' : '#D1D5DB'} strokeWidth="2.5"><path d="m9 18 6-6-6-6"/></svg>
              </div>
            ))}
          </div>
        </div>

        {/* Map */}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#EEF2F6' }}>
          <svg width="100%" height="100%" viewBox="0 0 640 448" preserveAspectRatio="xMidYMid slice">
            <defs>
              <filter id="ms"><feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.13"/></filter>
              <filter id="cs"><feDropShadow dx="0" dy="4" stdDeviation="10" floodOpacity="0.09"/></filter>
              <linearGradient id="waterGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#C4DCE8" stopOpacity="0.5"/>
                <stop offset="1" stopColor="#C4DCE8" stopOpacity="0.8"/>
              </linearGradient>
            </defs>

            {/* Land */}
            <rect width="640" height="448" fill="#EEF2F6"/>
            {/* Parks */}
            <rect x="228" y="196" width="110" height="76" rx="6" fill="#D4EBC8" opacity="0.85"/>
            <rect x="46" y="42" width="76" height="58" rx="4" fill="#D4EBC8" opacity="0.75"/>
            <rect x="520" y="300" width="80" height="90" rx="5" fill="#D4EBC8" opacity="0.7"/>
            {/* Water */}
            <path d="M0 406 Q 100 392 240 400 T 480 396 T 640 400 L 640 448 L 0 448 Z" fill="url(#waterGrad)"/>
            {/* Major roads */}
            <rect x="0" y="224" width="640" height="14" fill="#FFF" opacity="0.95"/>
            <rect x="304" y="0" width="14" height="448" fill="#FFF" opacity="0.95"/>
            <rect x="474" y="0" width="10" height="448" fill="#FFF" opacity="0.85"/>
            <rect x="126" y="0" width="10" height="448" fill="#FFF" opacity="0.85"/>
            <rect x="0" y="368" width="640" height="8" fill="#FFF" opacity="0.8"/>
            {/* Minor roads */}
            <rect x="0" y="144" width="640" height="5" fill="#F5F2EC" opacity="0.8"/>
            <rect x="0" y="314" width="640" height="5" fill="#F5F2EC" opacity="0.8"/>
            <rect x="206" y="0" width="5" height="448" fill="#F5F2EC" opacity="0.8"/>
            <rect x="416" y="0" width="5" height="448" fill="#F5F2EC" opacity="0.8"/>
            {/* Trees (parks) */}
            {[[248,212],[265,228],[282,212],[300,230],[318,214],[336,228],[60,56],[76,68],[88,54],[530,312],[546,328],[558,310]].map(([x,y],i) => (
              <circle key={i} cx={x} cy={y} r="5.5" fill="#4A9A5A" opacity="0.32"/>
            ))}
            {/* Building footprints */}
            {BLDGS.map(b => (
              <rect key={b.id} x={b.x} y={b.y} width={b.w} height={b.h} rx="3" fill={b.color} opacity={b.sel ? 0.2 : 0.1}/>
            ))}
            {/* Building markers */}
            {BLDGS.map(b => {
              const cx = b.x + b.w/2, cy = b.y - 18;
              return (
                <g key={b.id}>
                  {b.sel && <circle cx={cx} cy={cy} r="19" fill={b.color} opacity="0.12"/>}
                  <circle cx={cx} cy={cy} r={b.sel ? 13 : 9.5} fill="#fff" stroke={b.color} strokeWidth={b.sel ? 2.5 : 1.5} filter="url(#ms)"/>
                  <circle cx={cx} cy={cy} r={b.sel ? 5 : 3.5} fill={b.color}/>
                  {/* Stem */}
                  <line x1={cx} y1={b.y - 5} x2={cx} y2={b.y} stroke={b.color} strokeWidth="1.5" opacity="0.5"/>
                </g>
              );
            })}
            {/* Detail popup card for selected building */}
            <g filter="url(#cs)" transform="translate(348, 76)">
              <rect x="0" y="0" width="206" height="116" rx="10" fill="#FFFFFF"/>
              {/* Card header */}
              <rect x="12" y="12" width="30" height="30" rx="7" fill="#EFF9FF"/>
              <rect x="14" y="14" width="26" height="26" rx="6" fill="#E0F2FE" opacity="0.6"/>
              <text x="27" y="31" textAnchor="middle" fontSize="13" fill="#0EA5E9" fontFamily="system-ui">◈</text>
              <text x="48" y="24" fontSize="10.5" fontWeight="700" fill="#101828" fontFamily="system-ui">Engineering Building</text>
              <text x="48" y="36" fontSize="9" fill="#9CA3AF" fontFamily="system-ui">Academic · CS &amp; Engineering</text>
              {/* Divider */}
              <line x1="12" y1="50" x2="194" y2="50" stroke="#F0F4F8" strokeWidth="1"/>
              {/* Info */}
              <text x="12" y="65" fontSize="9" fill="#667085" fontFamily="system-ui">⏰  Mon–Fri 7am–9pm</text>
              <text x="12" y="79" fontSize="9" fill="#0EA5E9" fontFamily="system-ui">📍  ~4 min walk   ·   24 rooms</text>
              {/* Buttons */}
              <rect x="12" y="88" width="86" height="18" rx="5" fill="#0EA5E9"/>
              <text x="55" y="100" textAnchor="middle" fontSize="9.5" fill="#fff" fontFamily="system-ui" fontWeight="600">Get Directions</text>
              <rect x="104" y="88" width="72" height="18" rx="5" fill="#F0F9FF" stroke="#BAE6FD" strokeWidth="1"/>
              <text x="140" y="100" textAnchor="middle" fontSize="9.5" fill="#0EA5E9" fontFamily="system-ui" fontWeight="500">View Rooms</text>
            </g>
            {/* Map controls */}
            <g>
              <rect x="600" y="12" width="28" height="56" rx="7" fill="#fff" stroke="#E5E7EB" strokeWidth="1" filter="url(#ms)"/>
              <text x="614" y="35" textAnchor="middle" fontSize="16" fill="#6B7280" fontFamily="system-ui">+</text>
              <line x1="602" y1="43" x2="626" y2="43" stroke="#E5E7EB" strokeWidth="1"/>
              <text x="614" y="59" textAnchor="middle" fontSize="16" fill="#6B7280" fontFamily="system-ui">−</text>
              <rect x="600" y="74" width="28" height="28" rx="7" fill="#fff" stroke="#E5E7EB" strokeWidth="1"/>
              <text x="614" y="91" textAnchor="middle" fontSize="12" fill="#9CA3AF" fontFamily="system-ui">◎</text>
            </g>
            {/* Mapbox attribution */}
            <text x="634" y="444" textAnchor="end" fontSize="7.5" fill="#9CA3AF" fontFamily="system-ui" opacity="0.5">© Mapbox © OpenStreetMap</text>
          </svg>
        </div>
      </div>
    </div>
  );
};

// ——— Browser Mockup (for hero) ———
const BrowserMockup = () => {
  const isMobile = useIsMobile();
  const mockupScale = isMobile ? 0.85 : 1;

  return (
    <div style={{
      width: isMobile ? '100%' : 520, maxWidth: '100%',
      borderRadius: 12, overflow: 'hidden',
      boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05)',
      background: '#fff', transform: isMobile ? 'none' : 'perspective(1200px) rotateY(-4deg) rotateX(2deg)',
    }}>
      {/* Toolbar */}
      <div style={{
        height: 36, background: '#f9fafb', borderBottom: '1px solid #e5e7eb',
        display: 'flex', alignItems: 'center', padding: '0 12px', gap: 8,
      }}>
        <div style={{ display: 'flex', gap: 6 }}>
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#FF5F57' }}></span>
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#FEBC2E' }}></span>
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#28C840' }}></span>
        </div>
        <div style={{
          flex: 1, background: '#fff', borderRadius: 6, height: 22, margin: '0 32px 0 8px',
          display: 'flex', alignItems: 'center', padding: '0 10px',
          fontSize: 11, color: '#98a2b3', border: '1px solid #e5e7eb',
        }}>
          campus.youruni.edu/map
        </div>
      </div>

      {/* Map content */}
      <div style={{ display: 'flex', height: isMobile ? 200 : 320, overflow: 'hidden' }}>
        {/* Sidebar */}
        <div style={{ width: isMobile ? 120 : 160, borderRight: '1px solid #e5e7eb', padding: '10px 8px', background: '#fff', flexShrink: 0, overflow: 'hidden' }}>
          <div style={{ background: '#f3f4f6', borderRadius: 6, height: 26, marginBottom: 10, display: 'flex', alignItems: 'center', padding: '0 8px' }}>
            <span style={{ fontSize: 9, color: '#98a2b3' }}>Search buildings...</span>
          </div>
          {['Main Library', 'Engineering', 'Student Center', 'Science Lab', 'Admin Bldg'].map((b, i) => (
            <div key={b} style={{
              padding: '6px 8px', borderRadius: 6, marginBottom: 3, cursor: 'pointer',
              background: i === 1 ? 'var(--accent-subtle)' : 'transparent',
              borderLeft: i === 1 ? '3px solid var(--accent)' : '3px solid transparent',
            }}>
              <div style={{ fontSize: 9, fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1.3 }}>{b}</div>
              <div style={{ fontSize: 7, color: '#98a2b3', marginTop: 1 }}>{['Library', 'Academic', 'Student Life', 'Academic', 'Admin'][i]}</div>
            </div>
          ))}
        </div>

        {/* Map area */}
        <div style={{ flex: 1, background: '#EDF2F7', position: 'relative', overflow: 'hidden' }}>
          {/* Grid lines (roads) */}
          <svg width="100%" height="100%" style={{ position: 'absolute', top: 0, left: 0, opacity: 0.3 }}>
            <line x1="30%" y1="0" x2="30%" y2="100%" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="4 2"/>
            <line x1="65%" y1="0" x2="65%" y2="100%" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="4 2"/>
            <line x1="0" y1="35%" x2="100%" y2="35%" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="4 2"/>
            <line x1="0" y1="70%" x2="100%" y2="70%" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="4 2"/>
            {/* Paths */}
            <path d="M10% 20% Q 25% 50% 50% 45% T 90% 60%" stroke="#94a3b8" strokeWidth="3" fill="none" opacity="0.5"/>
          </svg>

          {/* Buildings */}
          {[
            { x: '12%', y: '15%', w: 60, h: 45, color: '#2563EB', label: 'ENG' },
            { x: '55%', y: '10%', w: 50, h: 65, color: '#7c3aed', label: 'LIB' },
            { x: '38%', y: '55%', w: 70, h: 40, color: '#059669', label: 'SCI' },
            { x: '72%', y: '50%', w: 45, h: 50, color: '#d97706', label: 'STU' },
            { x: '15%', y: '68%', w: 55, h: 35, color: '#dc2626', label: 'ADM' },
          ].map((b, i) => (
            <div key={i} style={{
              position: 'absolute', left: b.x, top: b.y, width: b.w, height: b.h,
              background: b.color, borderRadius: 4, opacity: 0.85,
              boxShadow: `0 2px 8px ${b.color}44`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              border: i === 0 ? '2px solid #fff' : 'none',
            }}>
              <span style={{ fontSize: 8, fontWeight: 700, color: '#fff', letterSpacing: '0.05em' }}>{b.label}</span>
            </div>
          ))}

          {/* Trees */}
          {[[45, 30], [82, 25], [25, 48], [70, 80], [50, 85], [88, 38]].map(([x, y], i) => (
            <div key={`t${i}`} style={{
              position: 'absolute', left: `${x}%`, top: `${y}%`,
              width: 8, height: 8, borderRadius: '50%',
              background: '#22c55e', opacity: 0.5,
            }}></div>
          ))}

          {/* Map controls */}
          <div style={{
            position: 'absolute', top: 8, right: 8, display: 'flex', flexDirection: 'column', gap: 2,
            background: '#fff', borderRadius: 4, boxShadow: '0 1px 3px rgba(0,0,0,0.1)', overflow: 'hidden',
          }}>
            <div style={{ width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: '#667085', cursor: 'pointer' }}>+</div>
            <div style={{ height: 1, background: '#e5e7eb' }}></div>
            <div style={{ width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: '#667085', cursor: 'pointer' }}>−</div>
          </div>

          {/* Selected building marker */}
          <div style={{
            position: 'absolute', left: 'calc(12% + 20px)', top: 'calc(15% - 20px)',
            width: 20, height: 20, borderRadius: '50%', background: 'var(--accent)',
            border: '2px solid #fff', boxShadow: '0 2px 6px rgba(37,99,235,0.4)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <div style={{ width: 4, height: 4, borderRadius: '50%', background: '#fff' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ——— University Logo Placeholder ———
const UniLogo = ({ name }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: 8, opacity: 0.35,
    filter: 'grayscale(100%)',
  }}>
    <div style={{
      width: 32, height: 32, borderRadius: '50%', border: '1.5px solid #94a3b8',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <Icon name="shield" size={16} />
    </div>
    <span style={{ fontSize: 13, fontWeight: 600, fontFamily: 'var(--font-display)', color: '#1e293b', letterSpacing: '-0.01em' }}>{name}</span>
  </div>
);

// ——— Pricing Card ———
const PricingCard = ({ plan, price, period, features, cta, popular, accentColor }) => {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: '#fff', borderRadius: 16, padding: 32, flex: 1, minWidth: 280, maxWidth: 400,
        border: popular ? `2px solid var(--accent)` : '1px solid var(--border)',
        boxShadow: popular
          ? (hovered ? 'var(--shadow-xl)' : 'var(--shadow-lg)')
          : (hovered ? 'var(--shadow-md)' : 'var(--shadow-sm)'),
        transition: 'all var(--duration-md) var(--ease)',
        transform: hovered ? 'translateY(-2px)' : 'none',
        position: 'relative',
      }}
    >
      {popular && (
        <div style={{
          position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)',
          background: 'var(--accent)', color: '#fff', fontSize: 12, fontWeight: 600,
          fontFamily: 'var(--font-display)', padding: '4px 16px', borderRadius: 9999,
        }}>Most Popular</div>
      )}
      <div style={{ fontSize: 18, fontWeight: 700, fontFamily: 'var(--font-display)', color: 'var(--text-primary)', marginBottom: 4 }}>{plan}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 20 }}>
        <span style={{ fontSize: 48, fontWeight: 800, fontFamily: 'var(--font-display)', color: 'var(--text-primary)', lineHeight: 1 }}>{price}</span>
        {period && <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>/{period}</span>}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 28 }}>
        {features.map((f, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ color: 'var(--success)', flexShrink: 0 }}><Icon name="check" size={16} /></div>
            <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>{f}</span>
          </div>
        ))}
      </div>
      <Button variant={popular ? 'pill' : 'pill-outline'} size="lg" style={{ width: '100%' }}>{cta}</Button>
    </div>
  );
};

// ——— Testimonial Card ———
const TestimonialCard = ({ name, title, university, quote }) => (
  <div style={{
    background: '#fff', borderRadius: 12, padding: 28, flex: 1, minWidth: 260,
    border: '1px solid var(--border-light)',
  }}>
    <p style={{ fontSize: 15, color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 20, fontStyle: 'italic' }}>"{quote}"</p>
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        width: 40, height: 40, borderRadius: '50%', background: 'var(--accent-subtle)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--accent)',
      }}>{name[0]}</div>
      <div>
        <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{name}</div>
        <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{title}, {university}</div>
      </div>
    </div>
  </div>
);

// Export to window
// ——— Dashboard Mockup (for feature showcase) ———
const DashboardMockup = () => {
  const isMobile = useIsMobile();
  return (
    <div style={{ borderRadius: 12, overflow: 'hidden', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.04)', background: '#fff', maxWidth: isMobile ? '100%' : 520 }}>
      {/* Toolbar */}
      <div style={{ height: 32, background: '#f9fafb', borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', padding: '0 12px', gap: 6 }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#FF5F57' }}></span>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#FEBC2E' }}></span>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#28C840' }}></span>
      </div>
      <div style={{ display: 'flex', height: isMobile ? 180 : 260 }}>
        {/* Sidebar */}
        <div style={{ width: isMobile ? 52 : 64, borderRight: '1px solid #e5e7eb', padding: '10px 6px', background: '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, borderRadius: 6, background: 'var(--accent-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }}></div>
          </div>
          {[1,2,3,4].map(i => <div key={i} style={{ width: 28, height: 28, borderRadius: 6, background: i === 1 ? 'var(--accent-subtle)' : '#f3f4f6' }}></div>)}
        </div>
        {/* Content */}
        <div style={{ flex: 1, padding: isMobile ? 10 : 16, overflow: 'hidden' }}>
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            {[{ n: '5', l: 'Buildings', c: 'var(--accent)' }, { n: '24', l: 'Rooms', c: '#7c3aed' }, { n: '●', l: 'Live', c: '#12B76A' }].map(s => (
              <div key={s.l} style={{ flex: 1, background: '#f9fafb', borderRadius: 8, padding: isMobile ? '8px 6px' : '10px 12px' }}>
                <div style={{ fontSize: isMobile ? 14 : 18, fontWeight: 800, fontFamily: 'var(--font-display)', color: s.c }}>{s.n}</div>
                <div style={{ fontSize: 8, color: '#98a2b3', marginTop: 2 }}>{s.l}</div>
              </div>
            ))}
          </div>
          {/* Table rows */}
          <div style={{ fontSize: 8, color: '#98a2b3', marginBottom: 4, display: 'flex', gap: 8, padding: '0 4px' }}><span style={{flex:2}}>Building</span><span style={{flex:1}}>Category</span><span style={{flex:1}}>Rooms</span></div>
          {['Main Library', 'Engineering', 'Student Center', 'Science Complex'].map((b, i) => (
            <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 4px', borderBottom: '1px solid #f3f4f6', fontSize: 9 }}>
              <span style={{ flex: 2, fontWeight: 600, color: '#101828' }}>{b}</span>
              <span style={{ flex: 1 }}><span style={{ background: '#f3f4f6', padding: '1px 6px', borderRadius: 9999, fontSize: 8, color: '#667085' }}>{['Library','Academic','Student','Academic'][i]}</span></span>
              <span style={{ flex: 1, color: '#667085' }}>{[12,24,8,18][i]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ——— Phone Mockup (for search feature) ———
const PhoneMockup = () => {
  const isMobile = useIsMobile();
  const h = isMobile ? 280 : 380;
  return (
    <div style={{
      width: isMobile ? 200 : 240, height: h, borderRadius: 28, overflow: 'hidden',
      boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.06)',
      background: '#fff', margin: '0 auto', position: 'relative',
      border: '6px solid #1a1a1a',
    }}>
      {/* Status bar */}
      <div style={{ height: 28, background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: 60, height: 16, borderRadius: 10, background: '#1a1a1a' }}></div>
      </div>
      {/* Content */}
      <div style={{ padding: '8px 12px', height: h - 40, overflowY: 'hidden' }}>
        <div style={{ fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)', marginBottom: 8, color: '#101828' }}>Campus Map</div>
        <div style={{ background: '#f3f4f6', borderRadius: 8, height: 28, display: 'flex', alignItems: 'center', padding: '0 10px', marginBottom: 10 }}>
          <span style={{ fontSize: 9, color: '#98a2b3' }}>Search buildings, rooms…</span>
        </div>
        {/* Filter chips */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 10 }}>
          {['All', 'Academic', 'Library'].map((c, i) => (
            <span key={c} style={{ fontSize: 8, padding: '3px 8px', borderRadius: 9999, background: i === 0 ? 'var(--accent)' : '#f3f4f6', color: i === 0 ? '#fff' : '#667085' }}>{c}</span>
          ))}
        </div>
        {/* Building cards */}
        {[{ name: 'Engineering Building', cat: 'Academic', d: '4 min', c: '#0EA5E9' }, { name: 'Main Library', cat: 'Library', d: '2 min', c: '#7c3aed' }, { name: 'Student Center', cat: 'Student Life', d: '1 min', c: '#f59e0b' }, { name: 'Science Complex', cat: 'Academic', d: '6 min', c: '#10b981' }].map(b => (
          <div key={b.name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: '1px solid #f3f4f6' }}>
            <div style={{ width: 24, height: 24, borderRadius: 6, background: `${b.c}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <div style={{ width: 8, height: 8, borderRadius: 2, background: b.c, opacity: 0.7 }}></div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 9, fontWeight: 600, color: '#101828', lineHeight: 1.3 }}>{b.name}</div>
              <div style={{ fontSize: 7, color: '#98a2b3' }}>{b.cat} · ~{b.d}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, {
  useIsMobile, useScrollReveal, Reveal, Icon, ICONS, Svg, Button, Container, FeatureIcon,
  Nav, BrowserMockup, CampusMapScreenshot, DashboardMockup, PhoneMockup, UniLogo, PricingCard, TestimonialCard,
});
