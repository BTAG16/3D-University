// dashboard-tabs.jsx — All 5 admin dashboard tab contents
const { useState, useEffect } = React;

// ——— Tab 1: Overview ———
const OverviewTab = ({ buildings, rooms }) => {
  const isMobile = useIsMobile();
  const mapStatus = buildings.length > 0;
  return (
    <div>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 32 }}>
        <StatCard label="Buildings" value={buildings.length} icon="building" />
        <StatCard label="Rooms" value={rooms.length} icon="door" />
        <StatCard label="Map Status" icon="globe"
          value={mapStatus ? <Badge color="green"><span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: '#12B76A', marginRight: 2 }}></span>Live</Badge> : <Badge color="gray">No buildings</Badge>}
        />
      </div>

      {/* Quick Actions */}
      <div style={{ marginBottom: 32 }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 16, marginBottom: 14, color: 'var(--text-primary)' }}>Quick Actions</h3>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          {[
            { label: 'Add a building', icon: 'building' },
            { label: 'Copy public link', icon: 'link' },
            { label: 'Manage rooms', icon: 'door' },
          ].map(a => (
            <button key={a.label} style={{
              display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px',
              borderRadius: 8, border: '1px solid var(--border)', background: '#fff',
              fontSize: 14, fontWeight: 500, color: 'var(--accent)', cursor: 'pointer',
              fontFamily: 'var(--font-body)', transition: 'all var(--duration) var(--ease)',
            }}>
              <Icon name={a.icon} size={16} /> {a.label} →
            </button>
          ))}
        </div>
      </div>

      {/* Getting Started */}
      {buildings.length < 3 && (
        <div style={{
          background: '#fff', borderRadius: 12, border: '1px solid var(--border-light)',
          padding: 24, boxShadow: 'var(--shadow-sm)',
        }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 16, marginBottom: 16, color: 'var(--text-primary)' }}>Getting Started</h3>
          {[
            { label: 'Account created', done: true },
            { label: 'Add first building', done: buildings.length > 0 },
            { label: 'Share your map', done: false },
          ].map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: i < 2 ? '1px solid var(--border-light)' : 'none' }}>
              <div style={{
                width: 22, height: 22, borderRadius: '50%',
                background: s.done ? 'var(--success)' : 'var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', flexShrink: 0,
              }}>
                {s.done && <Icon name="check" size={12} />}
              </div>
              <span style={{ fontSize: 14, color: s.done ? 'var(--text-tertiary)' : 'var(--text-primary)', textDecoration: s.done ? 'line-through' : 'none' }}>{s.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ——— Tab 2: Buildings ———
const BuildingsTab = ({ buildings, setBuildings, rooms }) => {
  const isMobile = useIsMobile();
  const [search, setSearch] = useState('');
  const [editPanel, setEditPanel] = useState(null); // null | 'new' | building object
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [selected, setSelected] = useState([]);

  const filtered = buildings.filter(b => b.name.toLowerCase().includes(search.toLowerCase()));

  const handleSave = (building) => {
    if (editPanel === 'new') {
      setBuildings([...buildings, { ...building, id: Date.now(), rooms: 0, status: 'active' }]);
    } else {
      setBuildings(buildings.map(b => b.id === building.id ? building : b));
    }
    setEditPanel(null);
  };

  const handleDelete = () => {
    if (deleteTarget) {
      setBuildings(buildings.filter(b => b.id !== deleteTarget.id));
      setDeleteTarget(null);
    }
  };

  const handleBulkDelete = () => {
    setBuildings(buildings.filter(b => !selected.includes(b.id)));
    setSelected([]);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, gap: 12, flexWrap: 'wrap' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22 }}>Buildings</h2>
        <button onClick={() => setEditPanel('new')} style={{
          display: 'flex', alignItems: 'center', gap: 6, padding: '10px 18px',
          borderRadius: 8, border: 'none', background: 'var(--accent)', color: '#fff',
          fontSize: 14, fontWeight: 600, fontFamily: 'var(--font-display)', cursor: 'pointer',
        }}>+ Add building</button>
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: 16 }}>
        <div style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }}>
          <Icon name="search" size={16} />
        </div>
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search buildings..." className="form-input"
          style={{ paddingLeft: 40, height: 42 }} />
      </div>

      {/* Bulk actions */}
      {selected.length > 0 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 16px', background: 'var(--error-subtle)', borderRadius: 8, marginBottom: 12 }}>
          <span style={{ fontSize: 14, fontWeight: 500 }}>{selected.length} selected</span>
          <button onClick={handleBulkDelete} style={{ fontSize: 13, fontWeight: 600, color: 'var(--error)', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--font-body)' }}>Delete selected</button>
        </div>
      )}

      {filtered.length === 0 ? (
        <EmptyState icon="building" title="No buildings yet" message="Add your first building to get your campus map started." action="Add building →" onAction={() => setEditPanel('new')} />
      ) : isMobile ? (
        /* Mobile: Cards */
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(b => (
            <div key={b.id} style={{
              background: '#fff', borderRadius: 10, border: '1px solid var(--border-light)',
              padding: 16, display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{b.name}</div>
                <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>{b.category} · {rooms.filter(r => r.buildingId === b.id).length} rooms</div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setEditPanel(b)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', padding: 4 }}><Icon name="externalLink" size={16} /></button>
                <button onClick={() => setDeleteTarget(b)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', padding: 4 }}><Icon name="x" size={16} /></button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Desktop: Table */
        <div style={{ background: '#fff', borderRadius: 12, border: '1px solid var(--border-light)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
            <thead>
              <tr style={{ background: '#f9fafb', borderBottom: '1px solid var(--border)' }}>
                <th style={{ padding: '10px 16px', textAlign: 'left', width: 36 }}>
                  <input type="checkbox" checked={selected.length === filtered.length && filtered.length > 0}
                    onChange={e => setSelected(e.target.checked ? filtered.map(b => b.id) : [])} />
                </th>
                <th style={thStyle}>Building name</th>
                <th style={thStyle}>Category</th>
                <th style={thStyle}>Rooms</th>
                <th style={thStyle}>Status</th>
                <th style={{ ...thStyle, textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(b => (
                <tr key={b.id} style={{ borderBottom: '1px solid var(--border-light)', cursor: 'pointer' }}
                  className="table-row">
                  <td style={{ padding: '12px 16px' }}>
                    <input type="checkbox" checked={selected.includes(b.id)}
                      onChange={e => setSelected(e.target.checked ? [...selected, b.id] : selected.filter(x => x !== b.id))} />
                  </td>
                  <td style={tdStyle}><span style={{ fontWeight: 600 }}>{b.name}</span></td>
                  <td style={tdStyle}><Badge>{b.category}</Badge></td>
                  <td style={tdStyle}>{rooms.filter(r => r.buildingId === b.id).length}</td>
                  <td style={tdStyle}><Badge color="green"><span style={{ display: 'inline-block', width: 5, height: 5, borderRadius: '50%', background: '#12B76A' }}></span> Live</Badge></td>
                  <td style={{ ...tdStyle, textAlign: 'right' }}>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                      <button onClick={() => setEditPanel(b)} title="Edit"
                        style={actionBtnStyle}><Icon name="externalLink" size={15} /></button>
                      <button onClick={() => setDeleteTarget(b)} title="Delete"
                        style={{ ...actionBtnStyle, color: 'var(--text-tertiary)' }}
                        onMouseEnter={e => e.currentTarget.style.color = 'var(--error)'}
                        onMouseLeave={e => e.currentTarget.style.color = 'var(--text-tertiary)'}>
                        <Icon name="x" size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Edit/Add panel */}
      <BuildingPanel open={!!editPanel} building={editPanel === 'new' ? null : editPanel}
        onClose={() => setEditPanel(null)} onSave={handleSave} />

      {/* Delete dialog */}
      <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={`Delete ${deleteTarget?.name}?`}
        message="This will also delete all rooms in this building. This action cannot be undone." />
    </div>
  );
};

const thStyle = { padding: '10px 16px', textAlign: 'left', fontWeight: 500, fontSize: 13, color: '#667085' };
const tdStyle = { padding: '12px 16px' };
const actionBtnStyle = { background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', padding: 4 };

// ——— Building Edit Panel ———
const BuildingPanel = ({ open, building, onClose, onSave }) => {
  const [form, setForm] = useState({});
  useEffect(() => {
    if (open) setForm(building || { name: '', category: 'Academic', lat: '', lng: '', description: '', hours: '', facilities: [], departments: [], mappedInUrl: '', isMain: false });
  }, [open, building]);
  const set = (k, v) => setForm({ ...form, [k]: v });

  return (
    <SlideOver open={open} onClose={onClose} title={building ? 'Edit building' : 'Add building'}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div>
          <label className="form-label">Building name</label>
          <input className="form-input" value={form.name || ''} onChange={e => set('name', e.target.value)} placeholder="e.g. Engineering Building" />
        </div>
        <div>
          <label className="form-label">Category</label>
          <select className="form-input" value={form.category || ''} onChange={e => set('category', e.target.value)}
            style={{ appearance: 'none', cursor: 'pointer' }}>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <label className="form-label">Latitude</label>
            <input className="form-input" value={form.lat || ''} onChange={e => set('lat', e.target.value)} placeholder="47.4734" />
          </div>
          <div style={{ flex: 1 }}>
            <label className="form-label">Longitude</label>
            <input className="form-input" value={form.lng || ''} onChange={e => set('lng', e.target.value)} placeholder="19.0598" />
          </div>
        </div>
        <div>
          <label className="form-label">Description</label>
          <textarea className="form-input" value={form.description || ''} onChange={e => set('description', e.target.value)}
            rows={3} placeholder="Brief description..." style={{ height: 'auto', padding: '12px 16px', resize: 'vertical' }} />
        </div>
        <div>
          <label className="form-label">Operating hours</label>
          <input className="form-input" value={form.hours || ''} onChange={e => set('hours', e.target.value)} placeholder="Mon–Fri 8am–6pm" />
        </div>
        <div>
          <label className="form-label">Facilities</label>
          <TagInput value={form.facilities || []} onChange={v => set('facilities', v)} placeholder="WiFi, Café, Parking..." />
        </div>
        <div>
          <label className="form-label">Departments</label>
          <TagInput value={form.departments || []} onChange={v => set('departments', v)} placeholder="Computer Science, Engineering..." />
        </div>
        <div>
          <label className="form-label">Indoor navigation URL (optional)</label>
          <input className="form-input" value={form.mappedInUrl || ''} onChange={e => set('mappedInUrl', e.target.value)} placeholder="https://app.mappedin.com/..." />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 0' }}>
          <span style={{ fontSize: 14, fontWeight: 500 }}>Feature as main building</span>
          <ToggleSwitch value={form.isMain} onChange={v => set('isMain', v)} />
        </div>
      </div>
      <div style={{ display: 'flex', gap: 12, marginTop: 28, justifyContent: 'flex-end', borderTop: '1px solid var(--border-light)', paddingTop: 20 }}>
        <button onClick={onClose} style={{ padding: '10px 20px', borderRadius: 8, border: '1px solid var(--border)', background: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)', color: 'var(--text-secondary)' }}>Cancel</button>
        <button onClick={() => onSave(form)} style={{ padding: '10px 20px', borderRadius: 8, border: 'none', background: 'var(--accent)', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)' }}>Save building</button>
      </div>
    </SlideOver>
  );
};

// ——— Toggle Switch ———
const ToggleSwitch = ({ value, onChange }) => (
  <button onClick={() => onChange(!value)} style={{
    width: 44, height: 24, borderRadius: 12, border: 'none', cursor: 'pointer',
    background: value ? 'var(--accent)' : 'var(--border)',
    position: 'relative', transition: 'background var(--duration) var(--ease)',
  }}>
    <span style={{
      position: 'absolute', top: 2, left: value ? 22 : 2,
      width: 20, height: 20, borderRadius: '50%', background: '#fff',
      boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
      transition: 'left var(--duration) var(--ease)',
    }}></span>
  </button>
);

// ——— Tab 3: Rooms ———
const RoomsTab = ({ rooms, setRooms, buildings }) => {
  const isMobile = useIsMobile();
  const [search, setSearch] = useState('');
  const [buildingFilter, setBuildingFilter] = useState('all');
  const [officeOnly, setOfficeOnly] = useState(false);
  const [editPanel, setEditPanel] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const filtered = rooms.filter(r => {
    if (buildingFilter !== 'all' && r.buildingId !== parseInt(buildingFilter)) return false;
    if (officeOnly && !r.isOffice) return false;
    const q = search.toLowerCase();
    return r.name.toLowerCase().includes(q) || r.number.toLowerCase().includes(q);
  });

  const getBuildingName = (id) => buildings.find(b => b.id === id)?.name || 'Unknown';

  const handleSave = (room) => {
    if (editPanel === 'new') {
      setRooms([...rooms, { ...room, id: Date.now() }]);
    } else {
      setRooms(rooms.map(r => r.id === room.id ? room : r));
    }
    setEditPanel(null);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 12 }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22 }}>Rooms</h2>
        <button onClick={() => setEditPanel('new')} style={{
          display: 'flex', alignItems: 'center', gap: 6, padding: '10px 18px',
          borderRadius: 8, border: 'none', background: 'var(--accent)', color: '#fff',
          fontSize: 14, fontWeight: 600, fontFamily: 'var(--font-display)', cursor: 'pointer',
        }}>+ Add room</button>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <select value={buildingFilter} onChange={e => setBuildingFilter(e.target.value)}
          className="form-input" style={{ width: isMobile ? '100%' : 220, height: 42, appearance: 'none', cursor: 'pointer' }}>
          <option value="all">All buildings</option>
          {buildings.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
        <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
          <div style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }}>
            <Icon name="search" size={16} />
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search rooms..." className="form-input" style={{ paddingLeft: 40, height: 42 }} />
        </div>
      </div>

      {/* Toggle */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {['All rooms', 'Offices only'].map((label, i) => (
          <button key={label} onClick={() => setOfficeOnly(i === 1)}
            style={{
              padding: '6px 16px', borderRadius: 9999, border: '1px solid var(--border)',
              background: (i === 0 && !officeOnly) || (i === 1 && officeOnly) ? 'var(--accent)' : '#fff',
              color: (i === 0 && !officeOnly) || (i === 1 && officeOnly) ? '#fff' : 'var(--text-secondary)',
              fontSize: 13, fontWeight: 500, cursor: 'pointer', fontFamily: 'var(--font-body)',
            }}>{label}</button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon="door" title="No rooms found" message="Add rooms to your buildings." action="Add room →" onAction={() => setEditPanel('new')} />
      ) : isMobile ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(r => (
            <div key={r.id} style={{ background: '#fff', borderRadius: 10, border: '1px solid var(--border-light)', padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontWeight: 600, fontSize: 15, color: 'var(--accent)' }}>{r.number}</span>
                    <span style={{ fontWeight: 500, fontSize: 15 }}>{r.name}</span>
                    {r.isOffice && <Badge color="sky">Office</Badge>}
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>{getBuildingName(r.buildingId)} · {r.purpose}</div>
                </div>
                <button onClick={() => setEditPanel(r)} style={actionBtnStyle}><Icon name="externalLink" size={15} /></button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ background: '#fff', borderRadius: 12, border: '1px solid var(--border-light)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
            <thead>
              <tr style={{ background: '#f9fafb', borderBottom: '1px solid var(--border)' }}>
                <th style={thStyle}>Room #</th>
                <th style={thStyle}>Name</th>
                <th style={thStyle}>Building</th>
                <th style={thStyle}>Type</th>
                <th style={thStyle}>Hours</th>
                <th style={{ ...thStyle, textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => (
                <tr key={r.id} style={{ borderBottom: '1px solid var(--border-light)' }} className="table-row">
                  <td style={tdStyle}><span style={{ fontWeight: 600, color: 'var(--accent)' }}>{r.number}</span></td>
                  <td style={tdStyle}>{r.name}</td>
                  <td style={tdStyle}>{getBuildingName(r.buildingId)}</td>
                  <td style={tdStyle}>{r.isOffice ? <Badge color="sky">Office</Badge> : <Badge>Room</Badge>}</td>
                  <td style={{ ...tdStyle, fontSize: 13, color: 'var(--text-secondary)' }}>{r.hours}</td>
                  <td style={{ ...tdStyle, textAlign: 'right' }}>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                      <button onClick={() => setEditPanel(r)} style={actionBtnStyle}><Icon name="externalLink" size={15} /></button>
                      <button onClick={() => setDeleteTarget(r)} style={{ ...actionBtnStyle, color: 'var(--text-tertiary)' }}
                        onMouseEnter={e => e.currentTarget.style.color = 'var(--error)'}
                        onMouseLeave={e => e.currentTarget.style.color = 'var(--text-tertiary)'}>
                        <Icon name="x" size={15} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <RoomPanel open={!!editPanel} room={editPanel === 'new' ? null : editPanel}
        buildings={buildings} onClose={() => setEditPanel(null)} onSave={handleSave} />

      <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)}
        onConfirm={() => { setRooms(rooms.filter(r => r.id !== deleteTarget.id)); setDeleteTarget(null); }}
        title={`Delete room ${deleteTarget?.number}?`} message="This action cannot be undone." />
    </div>
  );
};

// ——— Room Edit Panel ———
const RoomPanel = ({ open, room, buildings, onClose, onSave }) => {
  const [form, setForm] = useState({});
  useEffect(() => {
    if (open) setForm(room || { number: '', name: '', buildingId: buildings[0]?.id || 1, isOffice: false, purpose: '', hours: '', capacity: '', features: [], timetable: [] });
  }, [open, room]);
  const set = (k, v) => setForm({ ...form, [k]: v });

  return (
    <SlideOver open={open} onClose={onClose} title={room ? 'Edit room' : 'Add room'}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div style={{ display: 'flex', gap: 12 }}>
          <div style={{ flex: '0 0 120px' }}>
            <label className="form-label">Room number</label>
            <input className="form-input" value={form.number || ''} onChange={e => set('number', e.target.value)} placeholder="101" />
          </div>
          <div style={{ flex: 1 }}>
            <label className="form-label">Room name</label>
            <input className="form-input" value={form.name || ''} onChange={e => set('name', e.target.value)} placeholder="Main Lecture Hall" />
          </div>
        </div>
        <div>
          <label className="form-label">Building</label>
          <select className="form-input" value={form.buildingId || ''} onChange={e => set('buildingId', parseInt(e.target.value))} style={{ appearance: 'none' }}>
            {buildings.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '4px 0' }}>
          <span style={{ fontSize: 14, fontWeight: 500 }}>Is this an office?</span>
          <ToggleSwitch value={form.isOffice} onChange={v => set('isOffice', v)} />
        </div>
        <div>
          <label className="form-label">Purpose</label>
          <input className="form-input" value={form.purpose || ''} onChange={e => set('purpose', e.target.value)} placeholder="Professor's Office" />
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <label className="form-label">Operating hours</label>
            <input className="form-input" value={form.hours || ''} onChange={e => set('hours', e.target.value)} placeholder="Mon–Fri 9am–5pm" />
          </div>
          <div style={{ flex: '0 0 100px' }}>
            <label className="form-label">Capacity</label>
            <input className="form-input" type="number" value={form.capacity || ''} onChange={e => set('capacity', e.target.value)} placeholder="30" />
          </div>
        </div>
        <div>
          <label className="form-label">Features</label>
          <TagInput value={form.features || []} onChange={v => set('features', v)} placeholder="Projector, Whiteboard, AC..." />
        </div>
      </div>
      <div style={{ display: 'flex', gap: 12, marginTop: 28, justifyContent: 'flex-end', borderTop: '1px solid var(--border-light)', paddingTop: 20 }}>
        <button onClick={onClose} style={{ padding: '10px 20px', borderRadius: 8, border: '1px solid var(--border)', background: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)', color: 'var(--text-secondary)' }}>Cancel</button>
        <button onClick={() => onSave(form)} style={{ padding: '10px 20px', borderRadius: 8, border: 'none', background: 'var(--accent)', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)' }}>Save room</button>
      </div>
    </SlideOver>
  );
};

// ——— Tab 4: Public Link ———
const PublicLinkTab = () => {
  const [copied, setCopied] = useState(false);
  const [embedCopied, setEmbedCopied] = useState(false);
  const publicUrl = 'https://kampus3d.app/map?uni=budapest-tech';
  const embedCode = `<iframe src="${publicUrl}&embed=1" width="100%" height="600" frameborder="0"></iframe>`;

  const copy = (text, setter) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setter(true);
    setTimeout(() => setter(false), 2000);
  };

  return (
    <div style={{ maxWidth: 640 }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22, marginBottom: 24 }}>Share your campus map</h2>

      {/* Public URL */}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid var(--border-light)', padding: 24, marginBottom: 20 }}>
        <label className="form-label" style={{ marginBottom: 10 }}>Public URL</label>
        <div style={{ display: 'flex', gap: 8 }}>
          <input readOnly value={publicUrl} className="form-input" style={{ flex: 1, background: '#f9fafb', fontFamily: 'monospace', fontSize: 13 }} />
          <button onClick={() => copy(publicUrl, setCopied)} style={{
            padding: '0 16px', borderRadius: 8, border: '1px solid var(--border)',
            background: copied ? 'var(--success)' : '#fff', color: copied ? '#fff' : 'var(--text-secondary)',
            fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)',
            display: 'flex', alignItems: 'center', gap: 6, transition: 'all var(--duration) var(--ease)',
          }}>
            <Icon name={copied ? 'check' : 'link'} size={14} />
            {copied ? 'Copied!' : 'Copy'}
          </button>
        </div>
      </div>

      {/* Embed code */}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid var(--border-light)', padding: 24, marginBottom: 20 }}>
        <label className="form-label" style={{ marginBottom: 4 }}>Embed on your website</label>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 12 }}>Copy the code below and paste it into your website HTML.</p>
        <div style={{ background: '#0D1B2A', borderRadius: 8, padding: 16, marginBottom: 12, position: 'relative' }}>
          <code style={{ fontSize: 12, color: '#a5d6ff', fontFamily: 'monospace', lineHeight: 1.6, wordBreak: 'break-all' }}>{embedCode}</code>
          <button onClick={() => copy(embedCode, setEmbedCopied)} style={{
            position: 'absolute', top: 8, right: 8, padding: '4px 10px', borderRadius: 6,
            border: 'none', background: 'rgba(255,255,255,0.1)', color: '#a5d6ff',
            fontSize: 11, cursor: 'pointer', fontFamily: 'var(--font-display)',
          }}>{embedCopied ? 'Copied!' : 'Copy'}</button>
        </div>
        {/* Preview */}
        <div style={{ border: '1px solid var(--border)', borderRadius: 8, height: 120, background: '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>Embed preview</span>
        </div>
      </div>

      {/* Tips */}
      <div style={{ background: 'var(--accent-subtle)', borderRadius: 12, padding: 20 }}>
        <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14, marginBottom: 8, color: 'var(--accent)' }}>Sharing tips</h4>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          Share this link in your student portal, email newsletters, course handbooks, or embed it directly on your university website.
        </p>
      </div>
    </div>
  );
};

// ——— Tab 5: Settings ———
const SettingsTab = ({ universityName, setUniversityName }) => {
  const [city, setCity] = useState('Budapest');
  const [saved, setSaved] = useState(false);

  const handleSave = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  return (
    <div style={{ maxWidth: 560 }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22, marginBottom: 24 }}>Settings</h2>

      {/* University Details */}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid var(--border-light)', padding: 24, marginBottom: 20 }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 16, marginBottom: 18 }}>University Details</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <label className="form-label">University name</label>
            <input className="form-input" value={universityName} onChange={e => setUniversityName(e.target.value)} />
          </div>
          <div>
            <label className="form-label">City</label>
            <input className="form-input" value={city} onChange={e => setCity(e.target.value)} />
          </div>
          <button onClick={handleSave} style={{
            alignSelf: 'flex-start', padding: '10px 20px', borderRadius: 8, border: 'none',
            background: saved ? 'var(--success)' : 'var(--accent)', color: '#fff',
            fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)',
            transition: 'background var(--duration) var(--ease)',
          }}>{saved ? 'Saved!' : 'Save changes'}</button>
        </div>
      </div>

      {/* Account */}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid var(--border-light)', padding: 24, marginBottom: 20 }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 16, marginBottom: 18 }}>Account</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <label className="form-label">Email</label>
            <input className="form-input" value="admin@university.edu" disabled style={{ background: '#f9fafb', color: 'var(--text-tertiary)' }} />
          </div>
          <div>
            <label className="form-label">New password</label>
            <input className="form-input" type="password" placeholder="Enter new password" />
          </div>
          <div>
            <label className="form-label">Confirm new password</label>
            <input className="form-input" type="password" placeholder="Re-enter password" />
          </div>
          <button style={{
            alignSelf: 'flex-start', padding: '10px 20px', borderRadius: 8,
            border: '1px solid var(--border)', background: '#fff',
            fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)',
            color: 'var(--text-secondary)',
          }}>Update password</button>
        </div>
      </div>

      {/* Danger Zone */}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid var(--error)', padding: 24 }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 16, marginBottom: 8, color: 'var(--error)' }}>Danger Zone</h3>
        <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 16 }}>Permanently delete your account and all associated data.</p>
        <button style={{
          padding: '10px 20px', borderRadius: 8, border: 'none',
          background: 'var(--error)', color: '#fff', fontSize: 14, fontWeight: 600,
          cursor: 'pointer', fontFamily: 'var(--font-display)',
        }}>Delete account</button>
      </div>
    </div>
  );
};

Object.assign(window, {
  OverviewTab, BuildingsTab, RoomsTab, PublicLinkTab, SettingsTab, ToggleSwitch,
});
