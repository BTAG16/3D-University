// map-components.jsx — Public Map UI: Sidebar, BuildingCard, BuildingDetail, MapArea
const { useState, useEffect, useRef } = React;

// ——— Map Data ———
const MAP_BUILDINGS = [
  { id: 1, name: 'Main Library', category: 'Library', distance: '2 min', lat: 47.4734, lng: 19.0598, description: 'Central library with 3 floors of study areas, computer labs, and a ground-floor café.', hours: 'Mon–Fri 8am–10pm, Sat 9am–5pm', departments: ['Library Services'], facilities: ['WiFi', 'Café', 'Printing', 'Study Rooms'], mappedInUrl: 'https://app.mappedin.com/demo', rooms: [
    { number: '101', name: 'Main Reading Room', isOffice: false, purpose: 'Study area', hours: '8am–10pm' },
    { number: '201', name: 'Computer Lab A', isOffice: false, purpose: 'Computer lab', hours: '9am–8pm' },
    { number: '301', name: 'Quiet Study Zone', isOffice: false, purpose: 'Silent study', hours: '8am–10pm' },
  ], mapPos: { x: 28, y: 32 }, color: '#7c3aed' },
  { id: 2, name: 'Engineering Building', category: 'Academic', distance: '4 min', lat: 47.4741, lng: 19.0612, description: 'Home to the Faculty of Engineering and Computer Science. Contains lecture halls, labs, and faculty offices.', hours: 'Mon–Fri 7am–9pm', departments: ['Computer Science', 'Electrical Engineering', 'Mechanical Engineering'], facilities: ['WiFi', 'Parking', 'Lab', 'Vending Machines'], mappedInUrl: '', rooms: [
    { number: 'A-101', name: 'Lecture Hall 1', isOffice: false, purpose: 'Lectures', hours: '8am–6pm' },
    { number: 'A-205', name: 'Prof. Kovács Office', isOffice: true, purpose: "Professor's Office", hours: 'Mon–Thu 10am–4pm' },
    { number: 'B-102', name: 'Electronics Lab', isOffice: false, purpose: 'Lab work', hours: '9am–5pm' },
  ], mapPos: { x: 62, y: 22 }, color: '#0EA5E9' },
  { id: 3, name: 'Student Center', category: 'Student Life', distance: '1 min', lat: 47.4728, lng: 19.0605, description: 'Student services hub with dining hall, club rooms, and student affairs office.', hours: 'Mon–Sun 7am–11pm', departments: ['Student Affairs'], facilities: ['WiFi', 'Café', 'ATM', 'Lounge'], mappedInUrl: '', rooms: [
    { number: '102', name: 'Dining Hall', isOffice: false, purpose: 'Dining', hours: '7am–9pm' },
    { number: '201', name: 'Club Room', isOffice: false, purpose: 'Student clubs', hours: '10am–8pm' },
  ], mapPos: { x: 45, y: 58 }, color: '#f59e0b' },
  { id: 4, name: 'Science Complex', category: 'Academic', distance: '6 min', lat: 47.4738, lng: 19.0590, description: 'Physics, Chemistry, and Biology departments with state-of-the-art laboratories.', hours: 'Mon–Fri 8am–7pm', departments: ['Physics', 'Chemistry', 'Biology'], facilities: ['WiFi', 'Lab', 'Parking'], mappedInUrl: '', rooms: [
    { number: 'C-101', name: 'Physics Lab', isOffice: false, purpose: 'Experiments', hours: '9am–5pm' },
    { number: 'C-301', name: 'Dr. Szabó Office', isOffice: true, purpose: 'Department Head', hours: '9am–3pm' },
  ], mapPos: { x: 18, y: 65 }, color: '#10b981' },
  { id: 5, name: 'Admin Building', category: 'Administration', distance: '5 min', lat: 47.4745, lng: 19.0601, description: 'University administration, registrar, finance, and HR offices.', hours: 'Mon–Fri 9am–5pm', departments: ['Registrar', 'Finance', 'HR'], facilities: ['WiFi', 'Parking'], mappedInUrl: '', rooms: [
    { number: '101', name: 'Reception', isOffice: false, purpose: 'Front desk', hours: '9am–5pm' },
  ], mapPos: { x: 72, y: 55 }, color: '#ef4444' },
  { id: 6, name: 'Sports Center', category: 'Sports', distance: '8 min', lat: 47.4722, lng: 19.0615, description: 'Indoor gym, swimming pool, and outdoor sports facilities.', hours: 'Mon–Sat 6am–10pm', departments: [], facilities: ['WiFi', 'Locker Rooms', 'Pool', 'Gym'], mappedInUrl: '', rooms: [
    { number: 'GYM', name: 'Main Gym', isOffice: false, purpose: 'Fitness', hours: '6am–10pm' },
  ], mapPos: { x: 82, y: 78 }, color: '#ec4899' },
];

const FILTER_CATEGORIES = ['All', 'Academic', 'Library', 'Student Life', 'Administration', 'Sports'];

// ——— Building Card (sidebar list) ———
const BuildingCard = ({ building, selected, onClick }) => {
  const [hovered, setHovered] = useState(false);
  const catIcons = { Library: 'layers', Academic: 'building', 'Student Life': 'globe', Administration: 'shield', Sports: 'zap', Dining: 'globe' };
  return (
    <button onClick={onClick} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
        borderRadius: 10, border: 'none', cursor: 'pointer', textAlign: 'left',
        background: selected ? 'var(--accent-subtle)' : hovered ? '#f9fafb' : 'transparent',
        borderLeft: selected ? '4px solid var(--accent)' : '4px solid transparent',
        transition: 'all 150ms ease',
      }}>
      <div style={{
        width: 40, height: 40, borderRadius: 10, flexShrink: 0,
        background: `${building.color}15`, color: building.color,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={catIcons[building.category] || 'building'} size={18} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1.3 }}>{building.name}</div>
        <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2, display: 'flex', gap: 8 }}>
          <span>{building.category}</span>
          <span style={{ color: 'var(--accent)' }}>~{building.distance} walk</span>
        </div>
      </div>
      <div style={{ color: 'var(--text-tertiary)', flexShrink: 0 }}><Icon name="chevronRight" size={16} /></div>
    </button>
  );
};

// ——— Building Detail Panel ———
const BuildingDetail = ({ building, onBack, onDirections }) => {
  const [showRooms, setShowRooms] = useState(false);
  const catIcons = { Library: 'layers', Academic: 'building', 'Student Life': 'globe', Administration: 'shield', Sports: 'zap' };
  if (!building) return null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <button onClick={onBack} style={{
        display: 'flex', alignItems: 'center', gap: 6, padding: '12px 16px',
        background: 'none', border: 'none', cursor: 'pointer', fontSize: 14,
        color: 'var(--accent)', fontFamily: 'var(--font-body)', fontWeight: 500,
      }}>← All buildings</button>

      <div style={{ padding: '8px 20px 20px', flex: 1, overflowY: 'auto' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <div style={{
            width: 48, height: 48, borderRadius: 12, background: `${building.color}15`,
            color: building.color, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name={catIcons[building.category] || 'building'} size={22} />
          </div>
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20, margin: 0, lineHeight: 1.2 }}>{building.name}</h2>
            <span style={{ fontSize: 12, color: 'var(--text-tertiary)', background: '#f3f4f6', padding: '2px 8px', borderRadius: 9999, marginTop: 4, display: 'inline-block' }}>{building.category}</span>
          </div>
        </div>

        {/* Info rows */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
          <InfoRow icon="calendar" label="Hours" value={building.hours} />
          <InfoRow icon="compass" label="Distance" value={`~${building.distance} walk`} accent />
          {building.departments.length > 0 && (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', paddingLeft: 30 }}>
              {building.departments.map(d => (
                <span key={d} style={{ fontSize: 12, padding: '3px 10px', borderRadius: 9999, background: 'var(--accent-subtle)', color: 'var(--accent)' }}>{d}</span>
              ))}
            </div>
          )}
          {building.facilities.length > 0 && (
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', paddingLeft: 30 }}>
              {building.facilities.map(f => (
                <span key={f} style={{ fontSize: 12, padding: '3px 10px', borderRadius: 9999, background: '#f3f4f6', color: 'var(--text-secondary)' }}>{f}</span>
              ))}
            </div>
          )}
        </div>

        <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: 20 }}>
          {building.description}
        </p>

        {/* Actions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
          <ActionBtn primary label="Get Directions" icon="navigation" onClick={onDirections} />
          <ActionBtn label="View Rooms" icon="door" onClick={() => setShowRooms(!showRooms)} />
          {building.mappedInUrl && <ActionBtn label="Indoor Navigation" icon="layers" />}
        </div>

        {/* Rooms list */}
        {showRooms && (
          <div style={{ borderTop: '1px solid var(--border-light)', paddingTop: 16 }}>
            <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14, marginBottom: 12 }}>Rooms</h4>
            {building.rooms.map(r => (
              <div key={r.number} style={{
                padding: '10px 0', borderBottom: '1px solid var(--border-light)',
                display: 'flex', alignItems: 'center', gap: 10,
              }}>
                <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--accent)', minWidth: 50 }}>{r.number}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{r.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{r.purpose} · {r.hours}</div>
                </div>
                {r.isOffice && <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 9999, background: '#F0F9FF', color: '#0369A1' }}>Office</span>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const InfoRow = ({ icon, label, value, accent }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
    <div style={{ color: 'var(--text-tertiary)', flexShrink: 0 }}><Icon name={icon} size={16} /></div>
    <span style={{ fontSize: 14, color: accent ? 'var(--accent)' : 'var(--text-primary)' }}>{value}</span>
  </div>
);

const ActionBtn = ({ primary, label, icon, onClick }) => {
  const [hovered, setHovered] = useState(false);
  return (
    <button onClick={onClick} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        width: '100%', padding: '12px', borderRadius: 10, fontSize: 14, fontWeight: 600,
        fontFamily: 'var(--font-display)', cursor: 'pointer',
        background: primary ? (hovered ? 'var(--accent-hover)' : 'var(--accent)') : (hovered ? '#f9fafb' : '#fff'),
        color: primary ? '#fff' : 'var(--accent)',
        border: primary ? 'none' : '1px solid var(--border)',
        transition: 'all 150ms ease',
      }}>
      <Icon name={icon} size={16} /> {label}
    </button>
  );
};

// ——— Directions Panel ———
const DirectionsPanel = ({ building, onClose }) => {
  if (!building) return null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-light)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>Directions</h3>
        <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)' }}><Icon name="x" size={18} /></button>
      </div>
      <div style={{ padding: 20, flex: 1 }}>
        <div style={{ fontSize: 13, color: 'var(--text-tertiary)', marginBottom: 4 }}>From</div>
        <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 16, paddingBottom: 16, borderBottom: '1px solid var(--border-light)' }}>Your location</div>
        <div style={{ fontSize: 13, color: 'var(--text-tertiary)', marginBottom: 4 }}>To</div>
        <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--accent)', marginBottom: 20 }}>{building.name}</div>

        <div style={{
          background: 'var(--accent-subtle)', borderRadius: 12, padding: 20, textAlign: 'center', marginBottom: 20,
        }}>
          <div style={{ fontSize: 32, fontWeight: 800, fontFamily: 'var(--font-display)', color: 'var(--accent)' }}>~{building.distance}</div>
          <div style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>Estimated walking time</div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <a href="#" style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            padding: 12, borderRadius: 10, border: '1px solid var(--border)',
            fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', textDecoration: 'none',
          }}>
            <Icon name="externalLink" size={14} /> Open in Google Maps
          </a>
          <a href="#" style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            padding: 12, borderRadius: 10, border: '1px solid var(--border)',
            fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', textDecoration: 'none',
          }}>
            <Icon name="externalLink" size={14} /> Open in Apple Maps
          </a>
        </div>
      </div>
    </div>
  );
};

// ——— Map Area (placeholder) ———
const MapArea = ({ buildings, selectedId, onSelectBuilding }) => (
  <div style={{
    flex: 1, background: '#E8ECF0', position: 'relative', overflow: 'hidden',
  }}>
    {/* Map background pattern */}
    <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
      <defs>
        <pattern id="mapGrid" width="60" height="60" patternUnits="userSpaceOnUse">
          <rect width="60" height="60" fill="#E8ECF0"/>
          <path d="M60 0H0V60" fill="none" stroke="#D5DAE0" strokeWidth="0.5"/>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#mapGrid)"/>
      {/* Roads */}
      <line x1="0" y1="45%" x2="100%" y2="45%" stroke="#CDD3DA" strokeWidth="8" opacity="0.6"/>
      <line x1="35%" y1="0" x2="35%" y2="100%" stroke="#CDD3DA" strokeWidth="6" opacity="0.6"/>
      <line x1="70%" y1="0" x2="70%" y2="100%" stroke="#CDD3DA" strokeWidth="4" opacity="0.4"/>
      <path d="M10% 75% Q 40% 65% 60% 80% T 95% 70%" stroke="#CDD3DA" strokeWidth="5" fill="none" opacity="0.5"/>
      {/* Green areas */}
      <ellipse cx="50%" cy="48%" rx="8%" ry="6%" fill="#BBE5BB" opacity="0.4"/>
      <ellipse cx="15%" cy="15%" rx="6%" ry="5%" fill="#BBE5BB" opacity="0.35"/>
      <ellipse cx="88%" cy="40%" rx="5%" ry="4%" fill="#BBE5BB" opacity="0.3"/>
      {/* Water */}
      <path d="M0 90% Q 20% 82% 40% 88% T 100% 85%" fill="#B8D8F0" opacity="0.3"/>
    </svg>

    {/* Building footprints */}
    {buildings.map(b => (
      <div key={b.id} onClick={() => onSelectBuilding(b)}
        style={{
          position: 'absolute', left: `${b.mapPos.x}%`, top: `${b.mapPos.y}%`,
          transform: 'translate(-50%, -50%)', cursor: 'pointer', zIndex: 10,
        }}>
        {/* Building shape */}
        <div style={{
          width: 42 + (b.rooms?.length || 0) * 3, height: 28 + (b.rooms?.length || 0) * 2,
          background: b.color, borderRadius: 4, opacity: 0.25,
          position: 'absolute', top: 16, left: '50%', transform: 'translateX(-50%)',
        }}></div>
        {/* Marker */}
        <div style={{
          width: selectedId === b.id ? 40 : 34,
          height: selectedId === b.id ? 40 : 34,
          borderRadius: '50%', background: '#fff',
          boxShadow: selectedId === b.id
            ? `0 0 0 3px ${b.color}, 0 4px 12px rgba(0,0,0,0.15)`
            : '0 2px 8px rgba(0,0,0,0.12)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: b.color, transition: 'all 200ms ease', position: 'relative',
        }}>
          <Icon name="building" size={selectedId === b.id ? 18 : 15} />
        </div>
        {/* Label */}
        <div style={{
          position: 'absolute', top: '100%', left: '50%', transform: 'translateX(-50%)',
          marginTop: 14, whiteSpace: 'nowrap', fontSize: 11, fontWeight: 600,
          color: 'var(--text-primary)', background: 'rgba(255,255,255,0.9)',
          padding: '2px 8px', borderRadius: 4, textAlign: 'center',
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        }}>{b.name}</div>
      </div>
    ))}

    {/* Map controls */}
    <div style={{
      position: 'absolute', top: 16, right: 16, display: 'flex', flexDirection: 'column', gap: 8,
    }}>
      {['+', '−', '◎'].map(label => (
        <button key={label} style={{
          width: 36, height: 36, borderRadius: 8, border: '1px solid var(--border)',
          background: '#fff', fontSize: 16, cursor: 'pointer', color: 'var(--text-secondary)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: 'var(--shadow-sm)',
        }}>{label}</button>
      ))}
    </div>

    {/* Mapbox attribution */}
    <div style={{
      position: 'absolute', bottom: 4, right: 8, fontSize: 10, color: 'var(--text-tertiary)', opacity: 0.6,
    }}>© Mapbox © OpenStreetMap</div>
  </div>
);

// ——— Share Popover ———
const SharePopover = ({ open, onClose, url }) => {
  const [copied, setCopied] = useState(false);
  if (!open) return null;
  const handleCopy = () => {
    navigator.clipboard.writeText(url).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <>
      <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 50 }}></div>
      <div style={{
        position: 'absolute', top: 52, left: 16, zIndex: 51,
        background: '#fff', borderRadius: 12, padding: 20, width: 340, maxWidth: 'calc(100vw - 32px)',
        boxShadow: 'var(--shadow-xl)', border: '1px solid var(--border-light)',
      }}>
        <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 15, marginBottom: 12 }}>Share this campus map</h4>
        <div style={{ display: 'flex', gap: 8 }}>
          <input readOnly value={url} style={{
            flex: 1, height: 40, border: '1px solid var(--border)', borderRadius: 8,
            padding: '0 12px', fontSize: 13, fontFamily: 'monospace', background: '#f9fafb',
            outline: 'none', color: 'var(--text-primary)',
          }} />
          <button onClick={handleCopy} style={{
            padding: '0 14px', borderRadius: 8, border: 'none',
            background: copied ? '#12B76A' : 'var(--accent)', color: '#fff',
            fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-display)',
            transition: 'background 200ms ease',
          }}>{copied ? 'Copied!' : 'Copy'}</button>
        </div>
      </div>
    </>
  );
};

Object.assign(window, {
  MAP_BUILDINGS, FILTER_CATEGORIES, BuildingCard, BuildingDetail,
  DirectionsPanel, MapArea, SharePopover,
});
