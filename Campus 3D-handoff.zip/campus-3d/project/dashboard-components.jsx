// dashboard-components.jsx — Shared dashboard UI: Sidebar, Table, SlideOver, Dialog
const { useState, useEffect, useRef, createContext, useContext } = React;

// ——— Dashboard Context ———
const DashCtx = createContext();

// ——— Sample Data ———
const SAMPLE_BUILDINGS = [
  { id: 1, name: 'Main Library', category: 'Library', rooms: 12, status: 'active', lat: 47.4734, lng: 19.0598, description: 'Central library with study areas and computer labs.', hours: 'Mon–Fri 8am–10pm, Sat 9am–5pm', facilities: ['WiFi', 'Café', 'Printing'], departments: ['Library Services'], mappedInUrl: '', isMain: true },
  { id: 2, name: 'Engineering Building', category: 'Academic', rooms: 24, status: 'active', lat: 47.4741, lng: 19.0612, description: 'Faculty of Engineering and Computer Science.', hours: 'Mon–Fri 7am–9pm', facilities: ['WiFi', 'Parking', 'Lab'], departments: ['Computer Science', 'Engineering'], mappedInUrl: 'https://app.mappedin.com/demo', isMain: false },
  { id: 3, name: 'Student Center', category: 'Student Life', rooms: 8, status: 'active', lat: 47.4728, lng: 19.0605, description: 'Student services, clubs, and dining hall.', hours: 'Mon–Sun 7am–11pm', facilities: ['WiFi', 'Café', 'ATM'], departments: ['Student Affairs'], mappedInUrl: '', isMain: false },
  { id: 4, name: 'Science Complex', category: 'Academic', rooms: 18, status: 'active', lat: 47.4738, lng: 19.0590, description: 'Physics, Chemistry, and Biology departments.', hours: 'Mon–Fri 8am–7pm', facilities: ['WiFi', 'Lab', 'Parking'], departments: ['Physics', 'Chemistry', 'Biology'], mappedInUrl: '', isMain: false },
  { id: 5, name: 'Admin Building', category: 'Administration', rooms: 6, status: 'active', lat: 47.4745, lng: 19.0601, description: 'University administration offices.', hours: 'Mon–Fri 9am–5pm', facilities: ['WiFi', 'Parking'], departments: ['Registrar', 'Finance', 'HR'], mappedInUrl: '', isMain: false },
];

const SAMPLE_ROOMS = [
  { id: 1, number: '101', name: 'Main Reading Room', buildingId: 1, isOffice: false, purpose: 'Study area', hours: 'Mon–Fri 8am–10pm', capacity: 120, features: ['WiFi', 'Power Outlets', 'AC'], timetable: [] },
  { id: 2, number: '201', name: 'Computer Lab A', buildingId: 1, isOffice: false, purpose: 'Computer lab', hours: 'Mon–Fri 9am–8pm', capacity: 40, features: ['WiFi', 'Computers', 'Projector'], timetable: [{ day: 'Mon', start: '09:00', end: '11:00', label: 'CS 101' }, { day: 'Wed', start: '14:00', end: '16:00', label: 'IT Lab' }] },
  { id: 3, number: 'A-101', name: 'Lecture Hall 1', buildingId: 2, isOffice: false, purpose: 'Lectures', hours: 'Mon–Fri 8am–6pm', capacity: 200, features: ['Projector', 'Microphone', 'AC'], timetable: [{ day: 'Mon', start: '08:00', end: '10:00', label: 'ENG 201' }, { day: 'Tue', start: '10:00', end: '12:00', label: 'MATH 301' }] },
  { id: 4, number: 'A-205', name: 'Prof. Kovács Office', buildingId: 2, isOffice: true, purpose: "Professor's Office", hours: 'Mon–Thu 10am–4pm', capacity: 3, features: ['WiFi'], timetable: [{ day: 'Mon', start: '10:00', end: '12:00', label: 'Office Hours' }, { day: 'Thu', start: '14:00', end: '16:00', label: 'Office Hours' }] },
  { id: 5, number: 'B-102', name: 'Electronics Lab', buildingId: 2, isOffice: false, purpose: 'Lab work', hours: 'Mon–Fri 9am–5pm', capacity: 30, features: ['Lab Equipment', 'WiFi'], timetable: [] },
  { id: 6, number: '102', name: 'Dining Hall', buildingId: 3, isOffice: false, purpose: 'Dining', hours: 'Mon–Sun 7am–9pm', capacity: 300, features: ['WiFi'], timetable: [] },
  { id: 7, number: '201', name: 'Club Room', buildingId: 3, isOffice: false, purpose: 'Student clubs', hours: 'Mon–Fri 10am–8pm', capacity: 50, features: ['WiFi', 'Projector', 'Whiteboard'], timetable: [] },
  { id: 8, number: 'C-101', name: 'Physics Lab', buildingId: 4, isOffice: false, purpose: 'Physics experiments', hours: 'Mon–Fri 9am–5pm', capacity: 25, features: ['Lab Equipment', 'WiFi'], timetable: [{ day: 'Tue', start: '09:00', end: '12:00', label: 'PHY 201 Lab' }] },
  { id: 9, number: 'C-301', name: 'Dr. Szabó Office', buildingId: 4, isOffice: true, purpose: "Department Head Office", hours: 'Mon–Fri 9am–3pm', capacity: 4, features: ['WiFi'], timetable: [{ day: 'Wed', start: '10:00', end: '12:00', label: 'Office Hours' }] },
];

const CATEGORIES = ['Academic', 'Library', 'Dormitory', 'Administration', 'Sports', 'Dining', 'Student Life', 'Other'];

// ——— Sidebar ———
const Sidebar = ({ activeTab, setActiveTab, universityName }) => {
  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'layers' },
    { id: 'buildings', label: 'Buildings', icon: 'building' },
    { id: 'rooms', label: 'Rooms', icon: 'door' },
    { id: 'link', label: 'Public Link', icon: 'link' },
    { id: 'settings', label: 'Settings', icon: 'globe' },
  ];
  return (
    <aside style={{
      width: 240, background: '#fff', borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column', height: '100vh', position: 'fixed',
      top: 0, left: 0, zIndex: 40,
    }}>
      {/* Logo + Uni */}
      <div style={{ padding: '20px 20px 16px', borderBottom: '1px solid var(--border-light)' }}>
        <a href="Landing Page.html" style={{ display: 'flex', alignItems: 'center', gap: 8, textDecoration: 'none', marginBottom: 10 }}>
          <div style={{ color: 'var(--accent)' }}><Icon name="mapPin" size={20} /></div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--text-primary)' }}>Kampus</span>
        </a>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)', fontWeight: 500, padding: '6px 10px', background: 'var(--accent-subtle)', borderRadius: 6, textAlign: 'center' }}>
          {universityName}
        </div>
      </div>

      {/* Nav items */}
      <nav style={{ padding: '12px 12px', flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
        {tabs.map(t => {
          const active = activeTab === t.id;
          return (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
                borderRadius: 8, border: 'none', cursor: 'pointer', width: '100%',
                background: active ? 'var(--accent-subtle)' : 'transparent',
                color: active ? 'var(--accent)' : 'var(--text-secondary)',
                fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: active ? 600 : 500,
                transition: 'all var(--duration) var(--ease)', textAlign: 'left',
              }}>
              <Icon name={t.icon} size={18} />
              {t.label}
            </button>
          );
        })}
      </nav>

      {/* Bottom */}
      <div style={{ padding: '16px 20px', borderTop: '1px solid var(--border-light)' }}>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>admin@university.edu</div>
        <button style={{ fontSize: 13, color: 'var(--error)', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--font-body)', padding: 0 }}>Log out</button>
      </div>
    </aside>
  );
};

// ——— Mobile Bottom Bar ———
const MobileTabBar = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'overview', icon: 'layers', label: 'Overview' },
    { id: 'buildings', icon: 'building', label: 'Buildings' },
    { id: 'rooms', icon: 'door', label: 'Rooms' },
    { id: 'link', icon: 'link', label: 'Link' },
    { id: 'settings', icon: 'globe', label: 'Settings' },
  ];
  return (
    <nav style={{
      position: 'fixed', bottom: 0, left: 0, right: 0, height: 64,
      background: '#fff', borderTop: '1px solid var(--border)',
      display: 'flex', zIndex: 40,
    }}>
      {tabs.map(t => {
        const active = activeTab === t.id;
        return (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
              justifyContent: 'center', gap: 3, border: 'none', cursor: 'pointer',
              background: 'none', color: active ? 'var(--accent)' : 'var(--text-tertiary)',
              transition: 'color var(--duration) var(--ease)',
            }}>
            <Icon name={t.icon} size={20} />
            <span style={{ fontSize: 10, fontWeight: active ? 600 : 500 }}>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
};

// ——— Slide-Over Panel ———
const SlideOver = ({ open, onClose, title, children, width = 480 }) => {
  const isMobile = useIsMobile();
  if (!open) return null;
  return (
    <>
      <div onClick={onClose} style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', zIndex: 50,
        animation: 'fadeIn 200ms ease-out',
      }}/>
      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0,
        width: isMobile ? '100%' : width, maxWidth: '100%',
        background: '#fff', zIndex: 51, display: 'flex', flexDirection: 'column',
        boxShadow: 'var(--shadow-xl)',
        animation: 'slideIn 250ms ease-out',
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '16px 24px', borderBottom: '1px solid var(--border)',
        }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18 }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-secondary)', padding: 4 }}>
            <Icon name="x" size={20} />
          </button>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          {children}
        </div>
      </div>
    </>
  );
};

// ——— Confirm Dialog ———
const ConfirmDialog = ({ open, onClose, onConfirm, title, message }) => {
  if (!open) return null;
  return (
    <>
      <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', zIndex: 60 }}/>
      <div style={{
        position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
        background: '#fff', borderRadius: 16, padding: 28, width: 400, maxWidth: 'calc(100vw - 48px)',
        boxShadow: 'var(--shadow-xl)', zIndex: 61, textAlign: 'center',
      }}>
        <div style={{
          width: 48, height: 48, borderRadius: '50%', background: 'var(--error-subtle)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 16px', color: 'var(--error)', fontSize: 22, fontWeight: 700,
        }}>!</div>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, marginBottom: 8 }}>{title}</h3>
        <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 24, lineHeight: 1.5 }}>{message}</p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <button onClick={onClose} style={{
            padding: '10px 20px', borderRadius: 8, border: '1px solid var(--border)',
            background: '#fff', color: 'var(--text-secondary)', fontSize: 14, fontWeight: 600,
            fontFamily: 'var(--font-display)', cursor: 'pointer',
          }}>Cancel</button>
          <button onClick={onConfirm} style={{
            padding: '10px 20px', borderRadius: 8, border: 'none',
            background: 'var(--error)', color: '#fff', fontSize: 14, fontWeight: 600,
            fontFamily: 'var(--font-display)', cursor: 'pointer',
          }}>Delete</button>
        </div>
      </div>
    </>
  );
};

// ——— Stat Card ———
const StatCard = ({ label, value, icon, color = 'var(--accent)' }) => (
  <div style={{
    background: '#fff', borderRadius: 12, padding: 24, flex: 1, minWidth: 160,
    border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)',
  }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
      <div style={{
        width: 40, height: 40, borderRadius: 10, background: 'var(--accent-subtle)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: color,
      }}>
        <Icon name={icon} size={20} />
      </div>
    </div>
    <div style={{ fontSize: 32, fontWeight: 800, fontFamily: 'var(--font-display)', color: 'var(--text-primary)', lineHeight: 1 }}>{value}</div>
    <div style={{ fontSize: 14, color: 'var(--text-secondary)', marginTop: 4 }}>{label}</div>
  </div>
);

// ——— Badge ———
const Badge = ({ children, color = 'gray' }) => {
  const colors = {
    blue: { bg: '#EFF6FF', text: '#1D4ED8' },
    gray: { bg: '#F3F4F6', text: '#374151' },
    green: { bg: '#ECFDF3', text: '#027A48' },
    red: { bg: '#FEF3F2', text: '#B42318' },
    sky: { bg: '#F0F9FF', text: '#0369A1' },
  };
  const c = colors[color] || colors.gray;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 10px', borderRadius: 9999, fontSize: 12, fontWeight: 500,
      background: c.bg, color: c.text,
    }}>{children}</span>
  );
};

// ——— Tag Input ———
const TagInput = ({ value = [], onChange, placeholder = 'Add tag...' }) => {
  const [input, setInput] = useState('');
  const handleKey = (e) => {
    if ((e.key === 'Enter' || e.key === ',') && input.trim()) {
      e.preventDefault();
      if (!value.includes(input.trim())) onChange([...value, input.trim()]);
      setInput('');
    } else if (e.key === 'Backspace' && !input && value.length) {
      onChange(value.slice(0, -1));
    }
  };
  return (
    <div style={{
      border: '1px solid var(--border)', borderRadius: 8, padding: '6px 8px',
      display: 'flex', flexWrap: 'wrap', gap: 6, minHeight: 44, alignItems: 'center',
      background: '#fff',
    }}>
      {value.map(tag => (
        <span key={tag} style={{
          display: 'inline-flex', alignItems: 'center', gap: 4,
          padding: '3px 8px', borderRadius: 6, fontSize: 13,
          background: 'var(--accent-subtle)', color: 'var(--accent)',
        }}>
          {tag}
          <button onClick={() => onChange(value.filter(t => t !== tag))}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--accent)', padding: 0, lineHeight: 1, fontSize: 16 }}>×</button>
        </span>
      ))}
      <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey}
        placeholder={value.length ? '' : placeholder}
        style={{ border: 'none', outline: 'none', fontSize: 14, flex: 1, minWidth: 80, fontFamily: 'var(--font-body)', background: 'transparent' }} />
    </div>
  );
};

// ——— Toast ———
const Toast = ({ message, type = 'success', onDismiss }) => {
  useEffect(() => { const t = setTimeout(onDismiss, 3500); return () => clearTimeout(t); }, []);
  const colors = { success: '#12B76A', error: '#F04438', info: 'var(--accent)' };
  return (
    <div style={{
      position: 'fixed', top: 20, right: 20, zIndex: 100, minWidth: 280,
      background: '#fff', borderRadius: 8, padding: '12px 16px',
      boxShadow: 'var(--shadow-lg)', borderLeft: `4px solid ${colors[type] || colors.info}`,
      display: 'flex', alignItems: 'center', gap: 10,
      animation: 'slideIn 200ms ease-out', fontSize: 14, color: 'var(--text-primary)',
    }}>
      {message}
      <button onClick={onDismiss} style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)' }}>
        <Icon name="x" size={16} />
      </button>
    </div>
  );
};

// ——— Empty State ———
const EmptyState = ({ icon = 'building', title, message, action, onAction }) => (
  <div style={{ textAlign: 'center', padding: '64px 24px' }}>
    <div style={{
      width: 64, height: 64, borderRadius: 16, background: 'var(--accent-subtle)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      margin: '0 auto 20px', color: 'var(--accent)',
    }}>
      <Icon name={icon} size={28} />
    </div>
    <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 16, marginBottom: 6 }}>{title}</h3>
    <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: action ? 20 : 0 }}>{message}</p>
    {action && (
      <button onClick={onAction} style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '10px 20px', borderRadius: 8, border: 'none',
        background: 'var(--accent)', color: '#fff', fontSize: 14, fontWeight: 600,
        fontFamily: 'var(--font-display)', cursor: 'pointer',
      }}>
        {action}
      </button>
    )}
  </div>
);

Object.assign(window, {
  DashCtx, SAMPLE_BUILDINGS, SAMPLE_ROOMS, CATEGORIES,
  Sidebar, MobileTabBar, SlideOver, ConfirmDialog,
  StatCard, Badge, TagInput, Toast, EmptyState,
});
